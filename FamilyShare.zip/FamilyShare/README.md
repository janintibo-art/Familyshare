# FamilyShare

Partage de fichiers **pair-à-pair, sans serveur**, entre proches — à la manière
d'**eMule sur un réseau local**. On rejoint un **groupe** (Famille ou Amis) en
scannant un QR ; une fois dans le groupe, chacun voit le **catalogue commun** de
tous les fichiers partagés et **pioche ceux qu'il veut, directement sur le
téléphone qui les héberge**.

Application **Android** native (Kotlin + Jetpack Compose, Material 3).

---

## L'idée

1. Vous créez un groupe **Famille** ou **Amis** → l'app génère un **QR / lien**
   d'invitation (`familyshare://group?g=…`).
2. Vos proches scannent le QR (ou ouvrent le lien) → ils **rejoignent le groupe**.
3. Chacun met des fichiers **dans le pot commun** du groupe (choix d'un dossier).
4. Tout le monde voit **tous les fichiers partagés** par le groupe, avec le nom de
   celui qui les héberge, et **sélectionne ceux à télécharger**.
5. Le téléchargement se fait **en direct, de téléphone à téléphone** : on récupère
   le fichier sur l'appareil qui le possède. **Aucun serveur, aucun cloud.**

---

## Comment ça marche sans serveur

Trois briques, aucune infrastructure centrale (voir `p2p/LanGroupNetwork.kt`) :

- **Découverte automatique** — Android **NSD (mDNS/Bonjour)**. Chaque appareil
  publie un service `_familyshare._tcp` étiqueté avec l'ID du groupe. Les membres
  du même groupe, **sur le même Wi-Fi**, se découvrent tout seuls — rien à scanner
  entre chaque paire.
- **Chaque téléphone sert ses propres fichiers** — un **mini-serveur HTTP local**
  (NanoHTTPD) expose uniquement *vos* fichiers partagés :
  - `GET /catalog` → la liste de vos fichiers ;
  - `GET /file?id=…` → le fichier lui-même (lu via SAF).
  Ce n'est pas un serveur central : c'est votre téléphone qui sert ses fichiers
  aux membres du groupe, comme un partage local.
- **Catalogue commun** — l'app interroge le `/catalog` de chaque membre découvert
  et fusionne le tout. Vous piochez un fichier → il est téléchargé directement
  depuis l'appareil propriétaire.

Le **contrôle d'accès** vient du QR : il contient un secret de groupe ; un appareil
ne répond qu'aux membres présentant le bon secret.

### Membres à distance : un petit serveur de rendez-vous

La découverte automatique ci-dessus fonctionne **sur le même réseau local**. Pour
que le **QR de groupe marche aussi à distance** (et même quand les membres ne sont
pas tous en ligne en même temps), l'app utilise un **petit serveur de rendez-vous**
gratuit (dossier [`server/`](server/README.md)). Son rôle est limité à un
« standard téléphonique » :

- il met en relation les membres d'un même groupe (salles par ID de groupe) ;
- il relaie le **signaling WebRTC** entre deux membres ;
- il tient l'**index du catalogue** du groupe, pour qu'un membre qui se connecte
  plus tard voie les fichiers déjà annoncés.

**Vos fichiers ne passent jamais par lui** : une fois la connexion établie, les
octets vont **directement de téléphone à téléphone** (WebRTC). On obtient ainsi le
meilleur des deux mondes — découverte locale instantanée sur le même Wi-Fi, et
relais de rendez-vous pour les membres distants (`p2p/RendezvousClient.kt`).

> Renseignez l'URL `wss://` de votre serveur dans `AppConfig.kt` ; laissez `null`
> pour rester en mode 100 % local. Le pont 1-à-1 par ticket
> (`p2p/WebRtcManager.kt` + `p2p/ManualSignaling.kt`) reste disponible.

---

## Pile technique

- **Kotlin 2.1**, **Jetpack Compose** (BOM 2024.12), **Material 3** + couleur
  dynamique (Material You)
- **Navigation Compose**
- **NSD / mDNS** (framework Android) pour la découverte locale
- **NanoHTTPD** — mini-serveur de fichiers local par appareil
- **ZXing** — génération du QR de groupe + **scanner caméra** (zxing-android-embedded)
- **WebRTC** (stream-webrtc-android) — transfert direct entre téléphones distants
- **OkHttp** — WebSocket vers le serveur de rendez-vous
- **Serveur de rendez-vous** : Node.js + `ws` (dossier `server/`)
- **DataStore**, **DocumentFile** (SAF), **Coil**
- minSdk 24 · target/compileSdk 35 · JDK 17

---

## Structure du projet

```
app/src/main/java/com/familyshare/app/
├─ MainActivity.kt              # ouvre un lien familyshare://group → écran « Rejoindre »
├─ data/
│  ├─ model/Models.kt           # Group, GroupMember, SharedFile, TransferProgress…
│  └─ repository/GroupRepository.kt   # groupes + catalogue commun (données de démo)
├─ invite/GroupInvite.kt        # encode/décode le QR/lien de groupe (gzip + base64url)
├─ p2p/
│  ├─ LanGroupNetwork.kt        # ⭐ moteur sans serveur : NSD + serveur HTTP local + téléchargement
│  ├─ GroupSession.kt           # ⭐ orchestre local + rendez-vous + WebRTC → alimente l'UI
│  ├─ RendezvousClient.kt       # client WebSocket du serveur de rendez-vous (membres distants)
│  ├─ WebRtcManager.kt          # ⭐ transfert distant WebRTC (DataChannel) + réception galerie
│  └─ ManualSignaling.kt        # utilitaire QR (génération du QR de groupe)
├─ ui/
│  ├─ navigation/               # Destinations + AppNavHost
│  ├─ screens/
│  │  ├─ onboarding/            # accueil
│  │  └─ group/
│  │     ├─ GroupsScreen.kt         # liste des groupes Famille / Amis
│  │     ├─ CreateGroupScreen.kt    # créer un groupe
│  │     ├─ GroupQrScreen.kt        # QR/lien d'invitation
│  │     ├─ JoinGroupScreen.kt      # rejoindre via lien
│  │     ├─ GroupCatalogScreen.kt   # ⭐ catalogue commun + sélection + téléchargement
│  │     └─ GroupCatalogViewModel.kt# démarre/arrête la session de groupe
│  ├─ components/Components.kt
│  └─ theme/                    # palette corail/pêche/teal, clair & sombre
├─ di/AppModule.kt
└─ AppConfig.kt                 # ⚙️ URL du serveur de rendez-vous (à renseigner)
```

Et, à la racine, le serveur :

```
server/
├─ server.js                   # serveur de rendez-vous (signaling + index catalogue)
├─ package.json
└─ README.md                   # déploiement gratuit (Render/Railway/Fly/Glitch)
```

---

## Ce qui est réel vs à brancher

**Fonctionne tel quel (parcours complet, navigable) :**
- toute l'interface (accueil, groupes, création, QR, rejoindre, catalogue) ;
- encodage/décodage du **QR et du lien de groupe**, ouverture du lien par deep-link ;
- **rejoindre un groupe**, aperçu du groupe depuis le lien ;
- **contribuer ses fichiers** via le sélecteur de dossier du système (SAF) ;
- catalogue commun avec **propriétaire de chaque fichier**, état en ligne, et
  **sélection multiple** + bouton de téléchargement.

**Ce qui marche vraiment :**
- Toute l'UI + le QR/lien de groupe + **rejoindre (scan du QR via la caméra**, ou
  lien collé) + **partage réel d'un dossier**
  (SAF : énumération récursive du dossier et de ses sous-dossiers — noms, tailles, types, dates).
- **Le partage local (même Wi-Fi) est réel** : `LanGroupNetwork` découvre les
  membres (NSD/mDNS), chaque téléphone sert ses fichiers via un mini-serveur
  **NanoHTTPD** (`/catalog`, `/file`, protégés par le secret du groupe), et on
  **télécharge directement depuis le téléphone hôte** (HTTP) avec progression.
  Les fichiers reçus sont enregistrés dans la **galerie** (Photos / Vidéos /
  Musique, dossier « FamilyShare ») sur Android 10+, sinon dans le dossier de l'app.
- `GroupSession` relie le tout et alimente l'UI (membres en ligne, catalogue) ;
  l'écran démarre/arrête la session.
- **Vignettes** des images dans le catalogue (Coil) et **ouverture d'un fichier au
  tap** (mes fichiers et fichiers téléchargés).
- **Progression par fichier** (barre + pourcentage + vitesse + temps restant) et
  **annulation** d'un transfert en cours (coupure réelle côté LAN et WebRTC).
- **États clairs** : « Recherche des membres… » pendant la découverte, « Personne
  d'autre en ligne » avec une aide, et un message quand aucun fichier n'est partagé.
- **Service de premier plan** : les transferts continuent en arrière-plan / écran
  éteint, avec une notification de progression (le service s'arrête seul à la fin).
- **Gestion du groupe** : renommer, retirer un membre (local), régénérer le secret
  (réinvitation), et quitter le groupe — le tout persisté.
- **Recherche, filtres et tri** dans le catalogue : recherche par nom, filtres par
  type (images / vidéos / audio / autres) et tri (récents / nom / taille).
- **Partage récursif** : choisir un dossier partage aussi ses sous-dossiers
  (fichiers uniquement), avec garde-fous de profondeur et de nombre.
- **Aperçu plein écran** des images (zoom par pincement + déplacement) pour tes
  fichiers et ceux déjà téléchargés, sans quitter l'app.
- **Sélection groupée** : « Tout sélectionner » (respecte la recherche/le filtre)
  pour tout télécharger d'un coup.
- **Vue grille** : bascule liste ↔ grille de vignettes (3 colonnes) pour parcourir
  les photos confortablement.
- **Transfert local chiffré** : le contenu des fichiers transite chiffré (AES-CTR,
  clé dérivée du secret du groupe) sur le réseau local. Le distant WebRTC est déjà
  chiffré par DTLS. (Confidentialité contre l'écoute passive ; l'accès reste filtré
  par le secret.)
- **Mode hors ligne** : les fichiers téléchargés sont mémorisés (persistés) et restent
  visibles, ouvrables et avec leur vignette même sans réseau ou propriétaire hors ligne ;
  filtre « Hors ligne » et bannière de connectivité.
- **Gestion des téléchargements** : dans « Gérer le groupe », voir l'espace utilisé,
  supprimer un téléchargement ou tout supprimer pour libérer de l'espace.
- **Indicateur d'espace** : sur l'accueil, une barre stockage (autres usages /
  téléchargements FamilyShare / libre) qui se met à jour après suppression.
- **Persistance (DataStore)** : les groupes et **vos fichiers partagés** sont
  sauvegardés et restaurés au lancement ; le catalogue des autres reste du live réseau.
- Le **serveur de rendez-vous** (dossier `server/`) est complet et déployable.

**Transfert distant (WebRTC) — implémenté, à tester sur appareils :**
- `WebRtcManager` établit la connexion via le signaling relayé par le serveur de
  rendez-vous (offre / réponse / ICE) et transfère le fichier **directement** sur
  un DataChannel chiffré ; la réception est enregistrée dans la galerie.
- `GroupSession` route automatiquement : propriétaire **local** → HTTP direct ;
  propriétaire **distant** → WebRTC (dès qu'une URL `wss://` réelle est renseignée
  dans `AppConfig.kt` ; sinon le distant est simulé pour la démo).
- WebRTC se valide en conditions réelles (deux appareils, traversée de NAT) : c'est
  la partie à éprouver sur de vrais téléphones.

Chaque stub indique précisément quoi implémenter (`// TODO:` ciblés).

---

## Construire l'APK

> Le projet est livré en **scaffold** : il n'a pas pu être compilé dans
> l'environnement de génération (réseau désactivé, donc Gradle ne peut pas
> télécharger les dépendances).

1. Ouvrir **Android Studio** (Koala ou plus récent) → **File ▸ Open** → dossier
   `FamilyShare`. Android Studio régénère automatiquement le `gradle-wrapper.jar`
   (volontairement absent car binaire).
2. Laisser Gradle synchroniser (télécharge les dépendances).
3. **Run ▶** sur un appareil/émulateur, ou **Build ▸ Build APK(s)**.

Pour tester le partage local : installez l'app sur **deux téléphones du même
Wi-Fi**, créez un groupe sur l'un, scannez le QR avec l'autre.

---

## Permissions

`INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`,
`CHANGE_WIFI_MULTICAST_STATE` (mDNS/NSD), `POST_NOTIFICATIONS`, et
`NEARBY_WIFI_DEVICES` (Android 13+, `neverForLocation`) — **demandée au runtime** :
elle débloque l'accès au réseau local (protection du réseau local) nécessaire au
partage HTTP entre téléphones. `CAMERA` pour scanner le QR d'un groupe. Accès aux fichiers
via **SAF** (le système demande le dossier ; pas de permission de stockage large). Le trafic **HTTP en clair vers le réseau local** est autorisé (`usesCleartextTraffic`) pour le partage de fichiers local.

---

## Licence

MIT — voir [LICENSE](LICENSE).
