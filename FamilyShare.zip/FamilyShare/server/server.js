/**
 * FamilyShare — serveur de rendez-vous (signaling).
 *
 * Rôle : un simple "standard téléphonique" pour les groupes.
 *   - met en relation les membres d'un même groupe (salles par ID de groupe) ;
 *   - relaie le signaling WebRTC (offre / réponse / ICE) entre deux membres ;
 *   - tient un index du CATALOGUE de chaque groupe (qui partage quoi), pour que
 *     même un membre qui se connecte plus tard voie les fichiers déjà annoncés.
 *
 * Ce qu'il NE fait PAS : il ne voit jamais vos fichiers. Les octets des photos
 * et vidéos transitent en pair-à-pair (WebRTC), directement entre téléphones.
 *
 * Gratuit à héberger (Render / Railway / Fly / Glitch…). Voir README.md.
 *
 * Dépendance unique : `ws`.
 */

const http = require('http');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;

// rooms : Map<groupId, Room>
//   Room = { secret, members: Map<memberId, {ws, name}>, catalog: Map<memberId, files[]> }
const rooms = new Map();

function send(ws, obj) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj));
}

function broadcast(room, exceptId, obj) {
  for (const [id, m] of room.members) if (id !== exceptId) send(m.ws, obj);
}

// Petit serveur HTTP : page de santé (les hébergeurs gratuits la sondent).
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('FamilyShare rendezvous server — OK\n');
});

const wss = new WebSocketServer({ server });

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://localhost');
  const groupId = url.searchParams.get('group');
  const secret = url.searchParams.get('secret') || '';
  const memberId = url.searchParams.get('member');
  const name = url.searchParams.get('name') || 'Membre';

  if (!groupId || !memberId) {
    send(ws, { type: 'error', reason: 'missing group/member' });
    return ws.close();
  }

  let room = rooms.get(groupId);
  if (!room) {
    room = { secret, members: new Map(), catalog: new Map() };
    rooms.set(groupId, room);
  }
  // Contrôle d'accès : tous les membres d'un groupe présentent le même secret.
  if (room.secret && secret !== room.secret) {
    send(ws, { type: 'error', reason: 'bad secret' });
    return ws.close();
  }

  ws._groupId = groupId;
  ws._memberId = memberId;
  ws.isAlive = true;
  room.members.set(memberId, { ws, name });

  // Au nouvel arrivant : la liste des membres en ligne + le catalogue déjà connu.
  send(ws, {
    type: 'welcome',
    members: [...room.members.entries()].map(([id, m]) => ({ id, name: m.name })),
    catalog: [...room.catalog.values()].flat(),
  });
  // Aux autres : un nouveau membre est là.
  broadcast(room, memberId, { type: 'peer-joined', id: memberId, name });

  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data.toString()); } catch { return; }

    switch (msg.type) {
      // Relai ciblé du signaling WebRTC vers un membre précis (msg.to).
      case 'signal': {
        const target = room.members.get(msg.to);
        if (target) send(target.ws, { type: 'signal', from: memberId, data: msg.data });
        break;
      }
      // Un membre annonce les fichiers qu'il partage : on les indexe et on prévient.
      case 'catalog': {
        const files = (msg.files || []).map((f) => ({ ...f, ownerId: memberId, ownerName: name }));
        room.catalog.set(memberId, files);
        broadcast(room, memberId, { type: 'catalog', ownerId: memberId, ownerName: name, files });
        break;
      }
      case 'ping':
        send(ws, { type: 'pong' });
        break;
    }
  });

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('close', () => {
    const r = rooms.get(groupId);
    if (!r) return;
    r.members.delete(memberId);
    broadcast(r, memberId, { type: 'peer-left', id: memberId });
    // Salle vide : on la nettoie (l'index en mémoire est alors perdu ; les membres
    // ré-annoncent leur catalogue à la reconnexion).
    if (r.members.size === 0) rooms.delete(groupId);
  });
});

// Heartbeat : on ferme les connexions mortes toutes les 30 s.
const heartbeat = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);
wss.on('close', () => clearInterval(heartbeat));

server.listen(PORT, () => {
  console.log(`FamilyShare rendezvous server à l'écoute sur le port ${PORT}`);
});
