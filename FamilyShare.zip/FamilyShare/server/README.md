# Serveur de rendez-vous FamilyShare

Un petit « standard téléphonique » pour les groupes. Il met en relation les
membres, relaie le signaling WebRTC et tient l'index du catalogue de chaque
groupe. **Il ne voit jamais vos fichiers** : les photos et vidéos transitent en
pair-à-pair, directement entre téléphones.

Une seule dépendance (`ws`), idéal pour un hébergement gratuit.

## Lancer en local

```bash
cd server
npm install
npm start          # écoute sur http://localhost:8080
```

Vérification : ouvrez http://localhost:8080 → « FamilyShare rendezvous server — OK ».
Les téléphones se connectent en WebSocket sur la même URL (ws/wss).

## Déployer gratuitement

Le serveur lit le port via `process.env.PORT` (requis par la plupart des hébergeurs).

### Render (simple)
1. Poussez ce dossier sur un dépôt GitHub.
2. Render ▸ **New ▸ Web Service** ▸ choisissez le dépôt.
3. **Build Command** : `npm install` · **Start Command** : `npm start`.
4. Récupérez l'URL publique, ex. `https://familyshare-xxxx.onrender.com`.
   → l'app utilisera `wss://familyshare-xxxx.onrender.com`.

### Railway
`railway init` puis `railway up` — Railway détecte Node et lance `npm start`.

### Glitch
Importez le dépôt ; Glitch installe et démarre automatiquement.

### Fly.io
`fly launch` (génère un Dockerfile Node), puis `fly deploy`.

> Astuce : sur les offres gratuites, le serveur peut « s'endormir » après une
> période d'inactivité et se réveiller à la première connexion (quelques
> secondes). L'index du catalogue est en mémoire : un redémarrage le vide, et les
> membres le ré-annoncent automatiquement à la reconnexion.

## Brancher l'application

Dans l'app Android, ouvrez `app/.../AppConfig.kt` et renseignez l'URL **wss://**
de votre serveur déployé dans `RENDEZVOUS_URL`. Cette URL est ensuite encodée
dans le QR de groupe, pour que tout le monde rejoigne le même point de rendez-vous.

## Protocole (résumé)

Connexion : `wss://HOST?group=<id>&secret=<secret>&member=<id>&name=<nom>`

Messages (JSON) :
- serveur → client : `welcome` (membres + catalogue), `peer-joined`, `peer-left`,
  `signal` (offre/réponse/ICE relayés), `catalog` (fichiers d'un membre) ;
- client → serveur : `signal` (`to`, `data`), `catalog` (`files`), `ping`.
