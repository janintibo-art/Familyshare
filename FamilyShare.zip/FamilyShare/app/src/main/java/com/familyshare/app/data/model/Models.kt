package com.familyshare.app.data.model

import kotlinx.serialization.Serializable

/** Type de groupe (sert surtout à l'icône et au ton de l'interface). */
enum class GroupType { FAMILY, FRIENDS }

/** Un membre d'un groupe. */
@Serializable
data class GroupMember(
    val id: String,
    val displayName: String,
    val isMe: Boolean = false,
    val isOnline: Boolean = false,
    val endpoint: String? = null, // "ip:port" découvert sur le réseau local (NSD)
)

/**
 * Un groupe (Famille, Amis…). On le rejoint via un QR/lien contenant son [secret],
 * qui contrôle qui peut entrer. Une fois dans le groupe, chacun voit le catalogue
 * commun et pioche les fichiers directement chez celui qui les héberge.
 */
@Serializable
data class Group(
    val id: String,
    val name: String,
    val type: GroupType = GroupType.FAMILY,
    val secret: String,
    val createdAt: Long = System.currentTimeMillis(),
    val members: List<GroupMember> = emptyList(),
)

/**
 * Un fichier proposé dans un groupe. Il reste physiquement sur le téléphone de
 * son propriétaire ([ownerId]) ; [uri] est l'URI SAF valable côté propriétaire,
 * utilisée par SON mini-serveur local pour servir le fichier aux autres membres.
 */
@Serializable
data class SharedFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val mimeType: String,
    val uri: String,
    val ownerId: String,
    val ownerName: String,
    val modifiedAt: Long = 0L,
) {
    val kind: FileKind
        get() = when {
            mimeType.startsWith("image/") -> FileKind.IMAGE
            mimeType.startsWith("video/") -> FileKind.VIDEO
            mimeType.startsWith("audio/") -> FileKind.AUDIO
            else -> FileKind.OTHER
        }
}

enum class FileKind { IMAGE, VIDEO, AUDIO, OTHER }

/** Progression d'un téléchargement en cours. */
data class TransferProgress(
    val fileId: String,
    val fileName: String,
    val bytesTransferred: Long,
    val totalBytes: Long,
    val state: TransferState,
    val outputUri: String? = null,
    val bytesPerSec: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
) {
    val fraction: Float get() = if (totalBytes <= 0) 0f else bytesTransferred.toFloat() / totalBytes
    val etaSeconds: Long get() = if (bytesPerSec <= 0) -1 else (totalBytes - bytesTransferred) / bytesPerSec
}

enum class TransferState { PENDING, TRANSFERRING, DONE, FAILED, PAUSED }
