package com.familyshare.app.ui.screens.group

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.familyshare.app.di.AppModule
import com.familyshare.app.invite.GroupInviteCodec
import com.familyshare.app.ui.components.GradientBackground
import com.familyshare.app.ui.components.HintCard
import com.familyshare.app.ui.components.PrimaryButton
import com.familyshare.app.ui.theme.Teal
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinGroupScreen(
    onBack: () -> Unit,
    inviteLink: String? = null,
    onJoined: (String) -> Unit,
) {
    val repo = AppModule.repository
    var linkInput by remember { mutableStateOf(inviteLink ?: "") }
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // Aperçu du groupe si le lien est valide.
    val preview = remember(linkInput) { GroupInviteCodec.decode(linkInput) }

    // Scanner de QR (caméra) : remplit le lien à partir du code scanné.
    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        result.contents?.let { linkInput = it; error = null }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Rejoindre un groupe") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { inner ->
        GradientBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(inner)
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Teal.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.GroupAdd, contentDescription = null, tint = Teal, modifier = Modifier.size(38.dp))
                }
                Text(
                    "Scannez le QR du groupe, ou collez le lien d'invitation reçu.",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                )

                OutlinedButton(
                    onClick = {
                        scanLauncher.launch(
                            ScanOptions().apply {
                                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                setPrompt("Visez le QR du groupe")
                                setBeepEnabled(false)
                                setOrientationLocked(false)
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Icon(Icons.Rounded.QrCodeScanner, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Scanner le QR du groupe")
                }

                if (preview != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Teal.copy(alpha = 0.10f))
                            .padding(16.dp),
                    ) {
                        Text(
                            "Groupe : ${preview.name}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }

                OutlinedTextField(
                    value = linkInput,
                    onValueChange = { linkInput = it; error = null },
                    label = { Text("Lien d'invitation") },
                    placeholder = { Text("familyshare://group?g=…") },
                    singleLine = false,
                    minLines = 2,
                    shape = RoundedCornerShape(16.dp),
                    isError = error != null,
                    modifier = Modifier.fillMaxWidth(),
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Votre prénom") },
                    placeholder = { Text("Comment le groupe vous reconnaît") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                HintCard("Une fois dans le groupe, vous verrez tous les fichiers mis en commun et choisirez ceux à télécharger.")

                Spacer(Modifier.weight(1f))
                PrimaryButton(
                    text = "Rejoindre le groupe",
                    enabled = name.isNotBlank() && linkInput.isNotBlank(),
                    onClick = {
                        val invite = GroupInviteCodec.decode(linkInput)
                        if (invite != null) {
                            val g = repo.joinGroup(invite.id, invite.name, invite.type, invite.secret)
                            onJoined(g.id)
                        } else {
                            error = "Lien d'invitation invalide. Collez le lien familyshare://group reçu."
                        }
                    },
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
