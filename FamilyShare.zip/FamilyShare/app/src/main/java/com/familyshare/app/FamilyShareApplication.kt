package com.familyshare.app

import android.app.Application
import com.familyshare.app.data.repository.GroupRepository

/**
 * Classe Application. Point d'initialisation global (logs, conteneur de
 * dépendances, etc.). Volontairement minimale ici.
 */
class FamilyShareApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Restaure les groupes et mes fichiers partagés.
        GroupRepository.get().init(this)
    }
}
