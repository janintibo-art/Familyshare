package com.familyshare.app.p2p

import com.familyshare.app.data.model.Group
import com.familyshare.app.data.model.GroupMember
import com.familyshare.app.data.model.SharedFile
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Client du serveur de rendez-vous (voir `server/server.js`).
 *
 * Il assure la partie « mise en relation » du modèle distant :
 *   - rejoint la salle du groupe (WebSocket) ;
 *   - reçoit la liste des membres et le catalogue déjà connu ;
 *   - relaie le signaling WebRTC (offre / réponse / ICE) vers un membre précis,
 *     que [WebRtcManager] consomme pour établir la connexion directe ;
 *   - annonce mon catalogue et reçoit celui des autres.
 *
 * ⚠️ Les fichiers ne passent jamais par ce serveur : une fois la connexion WebRTC
 * établie via le signaling relayé ici, les octets vont directement de pair à pair.
 *
 * Hybride : sur le même Wi-Fi, on privilégie la découverte locale
 * ([LanGroupNetwork]) ; ce client sert pour les membres distants et pour
 * conserver un catalogue commun même quand tout le monde n'est pas en ligne.
 */
class RendezvousClient {

    interface Listener {
        fun onWelcome(members: List<GroupMember>, catalog: List<SharedFile>)
        fun onPeerJoined(member: GroupMember)
        fun onPeerLeft(memberId: String)
        /** Signaling WebRTC reçu d'un membre (à passer à [WebRtcManager]). */
        fun onSignal(fromMemberId: String, data: JSONObject)
        fun onCatalog(ownerId: String, ownerName: String, files: List<SharedFile>)
        fun onClosed(reason: String?) {}
    }

    private val client = OkHttpClient()
    private var socket: WebSocket? = null

    /** Rejoint la salle du groupe sur le serveur de rendez-vous. */
    fun connect(serverUrl: String, group: Group, me: GroupMember, listener: Listener) {
        fun q(v: String) = URLEncoder.encode(v, "UTF-8")
        val url = "$serverUrl?group=${q(group.id)}&secret=${q(group.secret)}" +
            "&member=${q(me.id)}&name=${q(me.displayName)}"

        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // Connexion établie ; le serveur enverra d'abord un message "welcome".
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val msg = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (msg.optString("type")) {
                    "welcome" -> listener.onWelcome(
                        parseMembers(msg.optJSONArray("members")),
                        parseFiles(msg.optJSONArray("catalog")),
                    )
                    "peer-joined" -> listener.onPeerJoined(
                        GroupMember(msg.optString("id"), msg.optString("name"), isOnline = true)
                    )
                    "peer-left" -> listener.onPeerLeft(msg.optString("id"))
                    "signal" -> listener.onSignal(msg.optString("from"), msg.optJSONObject("data") ?: JSONObject())
                    "catalog" -> listener.onCatalog(
                        msg.optString("ownerId"),
                        msg.optString("ownerName"),
                        parseFiles(msg.optJSONArray("files")),
                    )
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                listener.onClosed(reason)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onClosed(t.message)
            }
        })
    }

    /** Envoie un message de signaling WebRTC à un membre précis. */
    fun sendSignal(toMemberId: String, data: JSONObject) {
        val msg = JSONObject()
            .put("type", "signal")
            .put("to", toMemberId)
            .put("data", data)
        socket?.send(msg.toString())
    }

    /** Annonce au groupe les fichiers que je partage. */
    fun announceCatalog(files: List<SharedFile>) {
        val arr = JSONArray()
        files.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("sizeBytes", it.sizeBytes)
                    .put("mimeType", it.mimeType)
            )
        }
        val msg = JSONObject().put("type", "catalog").put("files", arr)
        socket?.send(msg.toString())
    }

    fun close() {
        socket?.close(1000, null)
        socket = null
    }

    private fun parseMembers(arr: JSONArray?): List<GroupMember> = buildList {
        if (arr == null) return@buildList
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            add(GroupMember(o.optString("id"), o.optString("name"), isOnline = true))
        }
    }

    private fun parseFiles(arr: JSONArray?): List<SharedFile> = buildList {
        if (arr == null) return@buildList
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            add(
                SharedFile(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    sizeBytes = o.optLong("sizeBytes"),
                    mimeType = o.optString("mimeType", "application/octet-stream"),
                    uri = "", // l'URI réelle vit chez le propriétaire ; le transfert se fait via WebRTC
                    ownerId = o.optString("ownerId"),
                    ownerName = o.optString("ownerName"),
                )
            )
        }
    }
}
