package com.familyshare.app.ui.screens.group

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.familyshare.app.di.AppModule
import com.familyshare.app.invite.GroupInvite
import com.familyshare.app.invite.GroupInviteCodec
import com.familyshare.app.p2p.ManualSignaling
import com.familyshare.app.ui.components.GradientBackground
import com.familyshare.app.ui.components.HintCard
import com.familyshare.app.ui.components.PrimaryButton
import com.familyshare.app.ui.theme.Coral
import com.familyshare.app.ui.theme.Teal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupQrScreen(
    groupId: String,
    onBack: () -> Unit,
    onOpenGroup: (String) -> Unit,
) {
    val repo = AppModule.repository
    val group = remember(groupId) { repo.groupById(groupId) }
    val context = LocalContext.current

    val link = remember(groupId) {
        group?.let {
            GroupInviteCodec.encodeToLink(
                GroupInvite(it.id, it.name, it.type, it.secret, com.familyshare.app.AppConfig.RENDEZVOUS_URL)
            )
        } ?: ""
    }
    val qr = remember(link) { runCatching { ManualSignaling.qrBitmap(link) }.getOrNull() }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Inviter au groupe") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { inner ->
        GradientBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(inner)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Text(
                    group?.name ?: "Groupe",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                Text(
                    "Toute personne qui scanne ce QR (ou ouvre le lien) rejoint le groupe.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )

                if (qr != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.White)
                            .padding(20.dp),
                    ) {
                        Image(
                            bitmap = qr.asImageBitmap(),
                            contentDescription = "QR code du groupe",
                            modifier = Modifier.size(230.dp),
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ShareAction(
                        icon = Icons.Rounded.Link,
                        label = "Lien",
                        tint = Coral,
                        modifier = Modifier.weight(1f),
                        onClick = { shareText(context, inviteText(group?.name ?: "notre groupe", link)) },
                    )
                    ShareAction(
                        icon = Icons.Rounded.Sms,
                        label = "SMS",
                        tint = Teal,
                        modifier = Modifier.weight(1f),
                        onClick = { shareViaSms(context, inviteText(group?.name ?: "notre groupe", link)) },
                    )
                }

                HintCard(
                    "Sur le même Wi-Fi, les membres se découvrent automatiquement une fois dans le " +
                        "groupe. Vos fichiers ne passent par aucun serveur : chacun sert les siens."
                )

                Spacer(Modifier.height(4.dp))
                PrimaryButton("Voir le groupe", onClick = { onOpenGroup(groupId) })
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ShareAction(
    icon: ImageVector,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(tint.copy(alpha = 0.10f))
            .clickable { onClick() }
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = tint)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    }
}

private fun inviteText(groupName: String, link: String): String =
    "Rejoins « $groupName » sur FamilyShare pour partager nos photos et vidéos.\n" +
        "Ouvre ce lien sur ton téléphone : $link"

private fun shareText(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Inviter via..."))
}

private fun shareViaSms(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        data = android.net.Uri.parse("sms:")
        putExtra("sms_body", text)
    }
    runCatching { context.startActivity(intent) }
}
