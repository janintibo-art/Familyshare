package com.familyshare.app.ui.theme

import androidx.compose.ui.graphics.Color

// Palette chaleureuse "famille" : corail, pêche, et tons crème.

val Coral = Color(0xFFFF6F61)
val CoralDark = Color(0xFFE65146)
val CoralLight = Color(0xFFFFA294)
val Peach = Color(0xFFFFB088)
val Teal = Color(0xFF2A9D8F)
val TealDark = Color(0xFF1F7268)

val Cream = Color(0xFFFFF4ED)
val Sand = Color(0xFFF6E9DF)
val Charcoal = Color(0xFF2B2622)
val Slate = Color(0xFF5C544E)

// Schéma clair
val LightPrimary = Coral
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFFFDAD3)
val LightOnPrimaryContainer = Color(0xFF410001)
val LightSecondary = Teal
val LightSecondaryContainer = Color(0xFFB6F0E6)
val LightOnSecondaryContainer = Color(0xFF00201C)
val LightBackground = Cream
val LightOnBackground = Charcoal
val LightSurface = Color(0xFFFFFBFF)
val LightSurfaceVariant = Sand
val LightOnSurfaceVariant = Slate
val LightOutline = Color(0xFFA08D82)

// Schéma sombre
val DarkPrimary = Color(0xFFFFB4A6)
val DarkOnPrimary = Color(0xFF690002)
val DarkPrimaryContainer = Color(0xFF93000A)
val DarkOnPrimaryContainer = Color(0xFFFFDAD3)
val DarkSecondary = Color(0xFF9AD4CA)
val DarkSecondaryContainer = Color(0xFF00504A)
val DarkOnSecondaryContainer = Color(0xFFB6F0E6)
val DarkBackground = Color(0xFF1A1110)
val DarkOnBackground = Color(0xFFF1DED8)
val DarkSurface = Color(0xFF221917)
val DarkSurfaceVariant = Color(0xFF534340)
val DarkOnSurfaceVariant = Color(0xFFD8C2BB)
val DarkOutline = Color(0xFFA08C87)
