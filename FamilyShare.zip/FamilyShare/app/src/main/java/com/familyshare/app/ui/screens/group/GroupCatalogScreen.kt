package com.familyshare.app.ui.screens.group

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import com.familyshare.app.data.model.FileKind
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.data.model.TransferProgress
import com.familyshare.app.data.model.TransferState
import com.familyshare.app.data.repository.GroupRepository
import com.familyshare.app.data.repository.formatBytes
import com.familyshare.app.di.AppModule
import com.familyshare.app.ui.components.FileKindIcon
import com.familyshare.app.ui.components.GradientBackground
import com.familyshare.app.ui.components.PrimaryButton
import com.familyshare.app.ui.theme.Coral
import com.familyshare.app.ui.theme.Teal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupCatalogScreen(
    groupId: String,
    onBack: () -> Unit,
    onInvite: (String) -> Unit,
    onManage: (String) -> Unit,
    viewModel: GroupCatalogViewModel = viewModel(),
) {
    val repo = AppModule.repository
    val context = LocalContext.current
    val appContext = context.applicationContext

    // Démarre la session de groupe (découverte locale + serveur de rendez-vous) à l'entrée.
    LaunchedEffect(groupId) { viewModel.start(appContext, groupId) }

    // Android 13+ : la permission « Appareils à proximité » est requise pour le
    // partage HTTP sur le réseau local (protection du réseau local).
    val needsNearby = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    var nearbyGranted by remember {
        mutableStateOf(
            !needsNearby ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.NEARBY_WIFI_DEVICES) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        nearbyGranted = granted
    }
    // Android 13+ : permission notifications pour afficher la progression des transferts.
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (!nearbyGranted) permLauncher.launch(Manifest.permission.NEARBY_WIFI_DEVICES)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val groups by repo.groups.collectAsState()
    val group = groups.firstOrNull { it.id == groupId }
    val catalogMap by repo.catalog.collectAsState()
    val downloadedMap by repo.downloaded.collectAsState()
    val downloads by repo.downloads.collectAsState()
    val offlineFiles = downloadedMap[groupId].orEmpty()
    val downloadedIds = offlineFiles.map { it.id }.toSet()
    val liveForGroup = catalogMap[groupId].orEmpty()
    // Fusionne le catalogue en direct avec la bibliothèque hors ligne : les fichiers
    // téléchargés gardent leur URI local et restent visibles, propriétaire hors ligne ou non.
    val files = remember(liveForGroup, offlineFiles) {
        val byId = LinkedHashMap<String, SharedFile>()
        liveForGroup.forEach { byId[it.id] = it }
        offlineFiles.forEach { off -> byId[off.id] = byId[off.id]?.copy(uri = off.uri) ?: off }
        byId.values.toList()
    }

    val onlineByOwner = group?.members?.associate { it.id to it.isOnline } ?: emptyMap()
    val otherOnline = group?.members?.count { !it.isMe && it.isOnline } ?: 0
    val searching by viewModel.searching.collectAsState()
    var query by remember { mutableStateOf("") }
    var kindFilter by remember { mutableStateOf<FileKind?>(null) }
    var sort by remember { mutableStateOf(CatalogSort.RECENT) }
    var previewUri by remember { mutableStateOf<String?>(null) }
    var previewName by remember { mutableStateOf("") }
    var gridMode by remember { mutableStateOf(false) }
    var offlineOnly by remember { mutableStateOf(false) }
    val isOnline by rememberIsOnline()
    val displayed = remember(files, query, kindFilter, sort, offlineOnly) {
        files.asSequence()
            .filter { !offlineOnly || it.uri.isNotEmpty() }
            .filter { kindFilter == null || it.kind == kindFilter }
            .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
            .sortedWith(
                when (sort) {
                    CatalogSort.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
                    CatalogSort.SIZE -> compareByDescending { it.sizeBytes }
                    CatalogSort.RECENT -> compareByDescending { it.modifiedAt }
                }
            )
            .toList()
    }
    val selected = remember { mutableStateListOf<String>() }

    // Contribuer mes propres fichiers au groupe (sélecteur de dossier SAF + lecture réelle).
    val scope = rememberCoroutineScope()
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch {
                val files = withContext(Dispatchers.IO) { readFolder(context, uri) }
                if (files.isNotEmpty()) {
                    repo.addMyFiles(groupId, files)
                    viewModel.onFilesContributed()
                }
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(group?.name ?: "Groupe", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { onInvite(groupId) }) {
                        Icon(Icons.Rounded.PersonAdd, contentDescription = "Inviter")
                    }
                    IconButton(onClick = { onManage(groupId) }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Gérer le groupe")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { inner ->
        GradientBackground {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = inner.calculateTopPadding()),
            ) {
                LazyVerticalGrid(
                    columns = if (gridMode) GridCells.Fixed(3) else GridCells.Fixed(1),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (!nearbyGranted) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            NearbyPermissionBanner(
                                onGrant = { permLauncher.launch(Manifest.permission.NEARBY_WIFI_DEVICES) },
                            )
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) { ShareMineButton(onClick = { pickFolder.launch(null) }) }
                    if (!isOnline) {
                        item(span = { GridItemSpan(maxLineSpan) }) { OfflineBanner(offlineCount = offlineFiles.size) }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) { MembersStrip(group?.members?.map { it.displayName to it.isOnline } ?: emptyList()) }
                    if (otherOnline == 0) {
                        item(span = { GridItemSpan(maxLineSpan) }) { DiscoveryStatus(searching = searching) }
                    }
                    if (files.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) { EmptyCatalog(othersOnline = otherOnline > 0) }
                    } else {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            CatalogControls(
                                query = query,
                                onQuery = { query = it },
                                kindFilter = kindFilter,
                                onKindFilter = { kindFilter = it },
                                sort = sort,
                                onSort = { sort = it },
                                gridMode = gridMode,
                                onToggleMode = { gridMode = !gridMode },
                                offlineOnly = offlineOnly,
                                onToggleOffline = { offlineOnly = !offlineOnly },
                            )
                        }
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            val selectableIds = displayed.filter {
                                if (it.ownerId == GroupRepository.ME_ID) return@filter false
                                if (it.id in downloadedIds) return@filter false
                                val st = downloads[it.id]?.state
                                st != TransferState.DONE && st != TransferState.TRANSFERRING
                            }.map { it.id }
                            val allSelected = selectableIds.isNotEmpty() && selectableIds.all { selected.contains(it) }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    if (displayed.size == files.size) "${files.size} fichier(s) dans le groupe"
                                    else "${displayed.size} sur ${files.size} fichier(s)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f),
                                )
                                if (selectableIds.isNotEmpty()) {
                                    TextButton(onClick = {
                                        if (allSelected) selected.removeAll(selectableIds)
                                        else selectableIds.forEach { if (!selected.contains(it)) selected.add(it) }
                                    }) {
                                        Text(if (allSelected) "Tout désélectionner" else "Tout sélectionner")
                                    }
                                }
                            }
                        }
                        if (displayed.isEmpty()) {
                            item(span = { GridItemSpan(maxLineSpan) }) { NoResults(onClear = { query = ""; kindFilter = null }) }
                        } else {
                        items(displayed, key = { it.id }) { file ->
                            val mine = file.ownerId == GroupRepository.ME_ID
                            val dl = downloads[file.id]
                                ?: if (!mine && file.id in downloadedIds)
                                    TransferProgress(file.id, file.name, file.sizeBytes, file.sizeBytes, TransferState.DONE, file.uri)
                                else null
                            val downloaded = dl?.state == TransferState.DONE
                            val thumbUri = if (file.uri.isNotEmpty()) file.uri else dl?.outputUri
                            val openUri = when {
                                mine && file.uri.isNotEmpty() -> file.uri
                                downloaded -> dl?.outputUri
                                else -> null
                            }
                            val onOpenLambda: (() -> Unit)? = openUri?.let { u ->
                                if (file.kind == FileKind.IMAGE) {
                                    { previewUri = u; previewName = file.name }
                                } else {
                                    { openFile(context, u, file.mimeType) }
                                }
                            }
                            val onToggleLambda: () -> Unit = {
                                if (selected.contains(file.id)) selected.remove(file.id) else selected.add(file.id)
                            }
                            if (gridMode) {
                                GridTile(
                                    file = file,
                                    mine = mine,
                                    selected = selected.contains(file.id),
                                    dl = dl,
                                    thumbUri = thumbUri,
                                    onOpen = onOpenLambda,
                                    onCancel = { viewModel.cancel(file.id) },
                                    onToggle = onToggleLambda,
                                )
                            } else {
                                FileRow(
                                    file = file,
                                    mine = mine,
                                    ownerOnline = onlineByOwner[file.ownerId] ?: false,
                                    selected = selected.contains(file.id),
                                    dl = dl,
                                    thumbUri = thumbUri,
                                    onOpen = onOpenLambda,
                                    onCancel = { viewModel.cancel(file.id) },
                                    onToggle = onToggleLambda,
                                )
                            }
                        }
                        }
                    }
                }

                if (selected.isNotEmpty()) {
                    DownloadBar(
                        count = selected.size,
                        bottomPadding = inner.calculateBottomPadding(),
                        onDownload = {
                            // Route chaque fichier vers le bon transport (local HTTP ou WebRTC distant).
                            viewModel.download(files.filter { selected.contains(it.id) })
                            selected.clear()
                        },
                    )
                }
            }
        }
    }

    previewUri?.let { u ->
        ImagePreview(uri = u, name = previewName, onClose = { previewUri = null })
    }
}

@Composable
private fun ShareMineButton(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Coral.copy(alpha = 0.10f))
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Coral.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, tint = Coral)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Partager mes fichiers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Choisir un dossier à mettre dans le pot commun",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MembersStrip(members: List<Pair<String, Boolean>>) {
    if (members.isEmpty()) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Teal.copy(alpha = 0.08f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        members.take(5).forEach { (name, online) ->
            Box(contentAlignment = Alignment.BottomEnd) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Coral.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(name.firstOrNull()?.uppercase() ?: "?", color = Coral, fontWeight = FontWeight.Bold)
                }
                if (online) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Teal),
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
        }
        Spacer(Modifier.width(2.dp))
        Text(
            "${members.count { it.second }} en ligne",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
    }
}

@Composable
private fun FileRow(
    file: SharedFile,
    mine: Boolean,
    ownerOnline: Boolean,
    selected: Boolean,
    dl: TransferProgress?,
    thumbUri: String?,
    onOpen: (() -> Unit)?,
    onCancel: () -> Unit,
    onToggle: () -> Unit,
) {
    val downloaded = dl?.state == TransferState.DONE
    val downloading = dl?.state == TransferState.TRANSFERRING
    // Ouvrir si possible (mes fichiers ou déjà téléchargés), sinon (autre, non téléchargé) sélectionner.
    val clickAction: (() -> Unit)? = onOpen ?: if (!mine && !downloaded && !downloading) onToggle else null

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (selected) Coral.copy(alpha = 0.10f) else MaterialTheme.colorScheme.surface
            )
            .let { m -> if (clickAction != null) m.clickable { clickAction() } else m }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (thumbUri != null && file.kind == FileKind.IMAGE) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp)),
            ) {
                AsyncImage(
                    model = thumbUri,
                    contentDescription = file.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        } else {
            FileKindIcon(file.kind)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(file.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                buildString {
                    append(if (mine) "Vous" else "par ${file.ownerName}")
                    if (!mine) append(if (ownerOnline) " • en ligne" else " • hors ligne")
                    append(" • ${formatBytes(file.sizeBytes)}")
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (downloading && dl != null) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { dl.fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = Coral,
                    trackColor = Coral.copy(alpha = 0.18f),
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    progressLabel(dl),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Trailing(
            mine = mine,
            selected = selected,
            downloaded = downloaded,
            downloading = downloading,
            onCancel = onCancel,
        )
    }
}

@Composable
private fun Trailing(
    mine: Boolean,
    selected: Boolean,
    downloaded: Boolean,
    downloading: Boolean,
    onCancel: () -> Unit,
) {
    when {
        mine -> Text("sur cet appareil", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        downloaded -> Box(
            modifier = Modifier.size(34.dp).clip(CircleShape).background(Teal.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Check, contentDescription = "Téléchargé", tint = Teal, modifier = Modifier.size(20.dp)) }
        downloading -> Box(
            modifier = Modifier.size(34.dp).clip(CircleShape).background(Coral.copy(alpha = 0.12f)).clickable { onCancel() },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Close, contentDescription = "Annuler", tint = Coral, modifier = Modifier.size(18.dp)) }
        else -> Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(if (selected) Coral else Color.Transparent)
                .let {
                    if (selected) it else it.clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
                },
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Icon(Icons.Rounded.Check, contentDescription = "Sélectionné", tint = Color.White, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun DownloadBar(count: Int, bottomPadding: androidx.compose.ui.unit.Dp, onDownload: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp + bottomPadding),
    ) {
        PrimaryButton(
            text = "Télécharger la sélection ($count)",
            onClick = onDownload,
        )
    }
}

@Composable
private fun NearbyPermissionBanner(onGrant: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Coral.copy(alpha = 0.12f))
            .padding(16.dp),
    ) {
        Text(
            "Activer le partage local",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Pour découvrir les téléphones du groupe sur le même Wi-Fi et télécharger leurs fichiers, autorisez « Appareils à proximité ».",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(6.dp))
        TextButton(onClick = onGrant) { Text("Autoriser") }
    }
}

/** Liste réellement les fichiers du dossier choisi (SAF) et les transforme en [SharedFile]. */
private const val MAX_FOLDER_DEPTH = 8
private const val MAX_FILES_PER_SHARE = 2000

/**
 * Énumère récursivement les fichiers d'un dossier SAF (sous-dossiers inclus),
 * avec des garde-fous de profondeur et de nombre pour rester réactif sur de
 * grandes arborescences. Les dossiers ne sont pas partagés, seulement les fichiers.
 */
private fun readFolder(context: android.content.Context, treeUri: Uri): List<SharedFile> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    val out = ArrayList<SharedFile>()
    fun walk(dir: DocumentFile, depth: Int) {
        if (depth > MAX_FOLDER_DEPTH || out.size >= MAX_FILES_PER_SHARE) return
        for (doc in dir.listFiles()) {
            if (out.size >= MAX_FILES_PER_SHARE) return
            when {
                doc.isDirectory -> walk(doc, depth + 1)
                doc.isFile -> {
                    val name = doc.name ?: continue
                    out.add(
                        SharedFile(
                            id = "me-" + Integer.toHexString(doc.uri.toString().hashCode()),
                            name = name,
                            sizeBytes = doc.length(),
                            mimeType = doc.type ?: guessMime(name),
                            uri = doc.uri.toString(),
                            ownerId = GroupRepository.ME_ID,
                            ownerName = "Moi",
                            modifiedAt = doc.lastModified(),
                        )
                    )
                }
            }
        }
    }
    walk(root, 0)
    return out
}

private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "gif" -> "image/gif"
    "webp" -> "image/webp"
    "heic", "heif" -> "image/heic"
    "mp4" -> "video/mp4"
    "mov" -> "video/quicktime"
    "mkv" -> "video/x-matroska"
    "webm" -> "video/webm"
    "3gp" -> "video/3gpp"
    "mp3" -> "audio/mpeg"
    "wav" -> "audio/wav"
    "m4a" -> "audio/mp4"
    "ogg" -> "audio/ogg"
    "pdf" -> "application/pdf"
    else -> "application/octet-stream"
}

/** Ouvre un fichier (mes fichiers ou téléchargés) dans l'app appropriée. */
private fun openFile(context: android.content.Context, uri: String, mime: String) {
    runCatching {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uri), mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}

private fun progressLabel(dl: TransferProgress): String {
    val pct = (dl.fraction * 100).toInt()
    val speed = if (dl.bytesPerSec > 0) " • ${formatBytes(dl.bytesPerSec)}/s" else ""
    val eta = if (dl.etaSeconds >= 0) " • ${formatEta(dl.etaSeconds)}" else ""
    return "$pct%$speed$eta"
}

private fun formatEta(seconds: Long): String = when {
    seconds < 60 -> "${seconds}s"
    seconds < 3600 -> "${seconds / 60} min ${seconds % 60}s"
    else -> "${seconds / 3600} h ${(seconds % 3600) / 60} min"
}

/** État de la découverte réseau quand personne d'autre n'est encore en ligne. */
@Composable
private fun DiscoveryStatus(searching: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (searching) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Coral)
            Spacer(Modifier.width(12.dp))
            Text(
                "Recherche des membres sur le réseau…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            Icon(
                Icons.Rounded.WifiTethering,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    "Personne d'autre en ligne pour l'instant",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "Demandez à vos proches d'ouvrir le groupe sur le même Wi-Fi, ou configurez le serveur distant pour partager via Internet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** État affiché quand aucun fichier n'est encore partagé dans le groupe. */
@Composable
private fun EmptyCatalog(othersOnline: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 40.dp, bottom = 24.dp, start = 16.dp, end = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(Coral.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.Inbox,
                contentDescription = null,
                tint = Coral,
                modifier = Modifier.size(32.dp),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Aucun fichier partagé",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (othersOnline)
                "Personne n'a encore ajouté de fichier. Partagez les vôtres avec le bouton ci-dessus."
            else
                "Partagez vos premiers fichiers avec le bouton ci-dessus, ou invitez vos proches à rejoindre le groupe.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

private enum class CatalogSort { RECENT, NAME, SIZE }

/** Barre de recherche + filtres par type + tri du catalogue. */
@Composable
private fun CatalogControls(
    query: String,
    onQuery: (String) -> Unit,
    kindFilter: FileKind?,
    onKindFilter: (FileKind?) -> Unit,
    sort: CatalogSort,
    onSort: (CatalogSort) -> Unit,
    gridMode: Boolean,
    onToggleMode: () -> Unit,
    offlineOnly: Boolean,
    onToggleOffline: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Rechercher un fichier") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Effacer")
                    }
                }
            },
        )
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OfflineChip(active = offlineOnly, onClick = onToggleOffline)
                KindChip("Tous", kindFilter == null) { onKindFilter(null) }
                KindChip("Images", kindFilter == FileKind.IMAGE) { onKindFilter(FileKind.IMAGE) }
                KindChip("Vidéos", kindFilter == FileKind.VIDEO) { onKindFilter(FileKind.VIDEO) }
                KindChip("Audio", kindFilter == FileKind.AUDIO) { onKindFilter(FileKind.AUDIO) }
                KindChip("Autres", kindFilter == FileKind.OTHER) { onKindFilter(FileKind.OTHER) }
            }
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onToggleMode) {
                Icon(
                    if (gridMode) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                    contentDescription = if (gridMode) "Vue liste" else "Vue grille",
                )
            }
            SortButton(sort = sort, onSort = onSort)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KindChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun SortButton(sort: CatalogSort, onSort: (CatalogSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Rounded.Sort, contentDescription = "Trier")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SortItem("Plus récents", sort == CatalogSort.RECENT) { onSort(CatalogSort.RECENT); open = false }
            SortItem("Nom (A→Z)", sort == CatalogSort.NAME) { onSort(CatalogSort.NAME); open = false }
            SortItem("Taille (décroissant)", sort == CatalogSort.SIZE) { onSort(CatalogSort.SIZE); open = false }
        }
    }
}

@Composable
private fun SortItem(label: String, selected: Boolean, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) },
        onClick = onClick,
        leadingIcon = { if (selected) Icon(Icons.Rounded.Check, contentDescription = null) },
    )
}

/** Affiché quand la recherche / le filtre ne renvoie aucun fichier. */
@Composable
private fun NoResults(onClear: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 32.dp, bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Rounded.SearchOff,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(40.dp),
        )
        Spacer(Modifier.height(10.dp))
        Text("Aucun résultat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Essayez un autre terme ou un autre filtre.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onClear) { Text("Réinitialiser") }
    }
}

/** Aperçu plein écran d'une image, avec zoom (pincer) et déplacement. */
@Composable
private fun ImagePreview(uri: String, name: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var scale by remember { mutableStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.94f))
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        offset = if (scale > 1f) offset + pan else Offset.Zero
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            AsyncImage(
                model = uri,
                contentDescription = name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
            )
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.35f))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Fermer", tint = Color.White)
                }
                Spacer(Modifier.width(4.dp))
                Text(name, color = Color.White, maxLines = 1, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

/** Tuile compacte d'un fichier pour la vue en grille. */
@Composable
private fun GridTile(
    file: SharedFile,
    mine: Boolean,
    selected: Boolean,
    dl: TransferProgress?,
    thumbUri: String?,
    onOpen: (() -> Unit)?,
    onCancel: () -> Unit,
    onToggle: () -> Unit,
) {
    val downloaded = dl?.state == TransferState.DONE
    val downloading = dl?.state == TransferState.TRANSFERRING
    val clickAction: (() -> Unit)? = onOpen ?: if (!mine && !downloaded && !downloading) onToggle else null
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Coral.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
            .let { m -> if (clickAction != null) m.clickable { clickAction() } else m }
            .padding(6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center,
        ) {
            if (thumbUri != null && file.kind == FileKind.IMAGE) {
                AsyncImage(
                    model = thumbUri,
                    contentDescription = file.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                FileKindIcon(file.kind)
            }
            Box(modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                when {
                    downloaded -> StatusBadge(Teal) {
                        Icon(Icons.Rounded.Check, contentDescription = "Téléchargé", tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    downloading -> Box(
                        modifier = Modifier.size(24.dp).clip(CircleShape).background(Coral).clickable { onCancel() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Annuler", tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    selected -> StatusBadge(Coral) {
                        Icon(Icons.Rounded.Check, contentDescription = "Sélectionné", tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            file.name,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.Medium,
        )
        if (downloading && dl != null) {
            Spacer(Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { dl.fraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = Coral,
                trackColor = Coral.copy(alpha = 0.18f),
            )
        } else {
            Text(
                formatBytes(file.sizeBytes),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun StatusBadge(color: Color, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(color),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Bannière affichée quand l'appareil n'a pas de réseau. */
@Composable
private fun OfflineBanner(offlineCount: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Coral.copy(alpha = 0.12f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.CloudOff, contentDescription = null, tint = Coral, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Hors ligne", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(
                if (offlineCount > 0)
                    "Vos fichiers et vos $offlineCount téléchargement(s) restent disponibles."
                else
                    "Seuls vos propres fichiers sont disponibles pour l'instant.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OfflineChip(active: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = active,
        onClick = onClick,
        label = { Text("Hors ligne") },
        leadingIcon = { Icon(Icons.Rounded.CloudDone, contentDescription = null, modifier = Modifier.size(18.dp)) },
    )
}

/** Suit l'état de connectivité réseau de l'appareil. */
@Composable
private fun rememberIsOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val online = remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        online.value = cm?.activeNetwork != null
        val callback = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) { online.value = true }
            override fun onLost(network: android.net.Network) { online.value = cm?.activeNetwork != null }
        }
        runCatching { cm?.registerDefaultNetworkCallback(callback) }
        onDispose { runCatching { cm?.unregisterNetworkCallback(callback) } }
    }
    return online
}
