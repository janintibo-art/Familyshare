package com.familyshare.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.familyshare.app.invite.GroupInviteCodec
import com.familyshare.app.ui.navigation.AppNavHost
import com.familyshare.app.ui.theme.FamilyShareTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Ouverture via un lien d'invitation de groupe : familyshare://group?g=…
        val link = intent?.data?.toString()
        val groupInvite = link?.takeIf { GroupInviteCodec.decode(it) != null }

        setContent {
            FamilyShareTheme {
                AppNavHost(startGroupInvite = groupInvite)
            }
        }
    }
}
