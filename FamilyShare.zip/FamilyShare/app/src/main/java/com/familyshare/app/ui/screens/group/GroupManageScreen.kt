package com.familyshare.app.ui.screens.group

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyshare.app.data.model.GroupType
import com.familyshare.app.data.repository.formatBytes
import com.familyshare.app.di.AppModule
import com.familyshare.app.ui.components.GradientBackground
import com.familyshare.app.ui.components.HintCard
import com.familyshare.app.ui.components.PrimaryButton
import com.familyshare.app.ui.theme.Coral
import com.familyshare.app.ui.theme.Teal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupManageScreen(
    groupId: String,
    onBack: () -> Unit,
    onShareInvite: (String) -> Unit,
    onLeft: () -> Unit,
) {
    val repo = AppModule.repository
    val groups by repo.groups.collectAsState()
    val group = groups.firstOrNull { it.id == groupId }
    val downloadedMap by repo.downloaded.collectAsState()
    val myDownloads = downloadedMap[groupId].orEmpty()
    val downloadsBytes = myDownloads.sumOf { it.sizeBytes }

    var name by remember { mutableStateOf(group?.name.orEmpty()) }
    var showRegenDialog by remember { mutableStateOf(false) }
    var showLeaveDialog by remember { mutableStateOf(false) }
    var showClearDownloads by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Gérer le groupe", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { inner ->
        GradientBackground {
            if (group == null) {
                Box(Modifier.fillMaxSize().padding(inner), contentAlignment = Alignment.Center) {
                    Text("Groupe introuvable", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                return@GradientBackground
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(inner)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Spacer(Modifier.height(8.dp))

                // --- Nom du groupe ---
                SectionTitle("Nom du groupe")
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                PrimaryButton(
                    text = "Renommer",
                    onClick = { repo.renameGroup(groupId, name) },
                    enabled = name.isNotBlank() && name.trim() != group.name,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    if (group.type == GroupType.FAMILY) "Type : famille" else "Type : amis",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )

                Spacer(Modifier.height(24.dp))

                // --- Membres ---
                SectionTitle("Membres (${group.members.size})")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface),
                ) {
                    group.members.forEach { member ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(if (member.isOnline) Teal else MaterialTheme.colorScheme.outline),
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                member.displayName + if (member.isMe) " (vous)" else "",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (member.isMe) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.weight(1f),
                            )
                            if (!member.isMe) {
                                IconButton(onClick = { repo.removeMember(groupId, member.id) }) {
                                    Icon(
                                        Icons.Rounded.Close,
                                        contentDescription = "Retirer ${member.displayName}",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
                HintCard(
                    text = "Retirer un membre le masque seulement chez vous. Sans serveur central, " +
                        "il peut rejoindre à nouveau avec le lien : pour l'exclure vraiment, régénérez le secret.",
                    modifier = Modifier.padding(top = 10.dp),
                )

                Spacer(Modifier.height(24.dp))

                // --- Téléchargements ---
                SectionTitle("Téléchargements")
                if (myDownloads.isEmpty()) {
                    Text(
                        "Aucun fichier téléchargé sur cet appareil pour ce groupe.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        "${myDownloads.size} fichier(s) • ${formatBytes(downloadsBytes)} sur cet appareil",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surface),
                    ) {
                        myDownloads.forEach { d ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(d.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, fontWeight = FontWeight.Medium)
                                    Text(
                                        "${d.ownerName} • ${formatBytes(d.sizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { repo.removeDownload(groupId, d.id) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { showClearDownloads = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text("Tout supprimer (libérer ${formatBytes(downloadsBytes)})", color = MaterialTheme.colorScheme.error)
                    }
                }

                Spacer(Modifier.height(24.dp))

                // --- Secret ---
                SectionTitle("Secret du groupe")
                Text(
                    "Le secret protège l'accès aux fichiers et est inclus dans le QR d'invitation. " +
                        "Le régénérer invalide les anciennes invitations.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                PrimaryButton(
                    text = "Régénérer le secret",
                    onClick = { showRegenDialog = true },
                    leadingIcon = Icons.Rounded.Refresh,
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(Modifier.height(24.dp))

                // --- Quitter ---
                SectionTitle("Quitter")
                TextButton(
                    onClick = { showLeaveDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(8.dp))
                    Text("Quitter le groupe", color = MaterialTheme.colorScheme.error)
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }

    if (showRegenDialog) {
        AlertDialog(
            onDismissRequest = { showRegenDialog = false },
            title = { Text("Régénérer le secret ?") },
            text = {
                Text(
                    "Les invitations déjà partagées ne fonctionneront plus. Vous devrez partager " +
                        "le nouveau QR / lien aux membres pour qu'ils gardent l'accès.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    repo.regenerateSecret(groupId)
                    showRegenDialog = false
                    onShareInvite(groupId)
                }) { Text("Régénérer et partager") }
            },
            dismissButton = {
                TextButton(onClick = { showRegenDialog = false }) { Text("Annuler") }
            },
        )
    }

    if (showLeaveDialog) {
        AlertDialog(
            onDismissRequest = { showLeaveDialog = false },
            title = { Text("Quitter le groupe ?") },
            text = {
                Text(
                    "Le groupe sera retiré de cet appareil. Vous pourrez le rejoindre à nouveau " +
                        "avec une invitation valide.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showLeaveDialog = false
                    repo.leaveGroup(groupId)
                    onLeft()
                }) { Text("Quitter", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveDialog = false }) { Text("Annuler") }
            },
        )
    }

    if (showClearDownloads) {
        AlertDialog(
            onDismissRequest = { showClearDownloads = false },
            title = { Text("Supprimer les téléchargements ?") },
            text = {
                Text(
                    "Les ${myDownloads.size} fichier(s) téléchargés pour ce groupe seront supprimés " +
                        "de cet appareil (${formatBytes(downloadsBytes)} libérés). Ils restent disponibles " +
                        "auprès des membres.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showClearDownloads = false
                    repo.clearDownloads(groupId)
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearDownloads = false }) { Text("Annuler") }
            },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = Coral,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}
