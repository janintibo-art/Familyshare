package com.familyshare.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.familyshare.app.ui.screens.group.CreateGroupScreen
import com.familyshare.app.ui.screens.group.GroupCatalogScreen
import com.familyshare.app.ui.screens.group.GroupManageScreen
import com.familyshare.app.ui.screens.group.GroupQrScreen
import com.familyshare.app.ui.screens.group.GroupsScreen
import com.familyshare.app.ui.screens.group.JoinGroupScreen
import com.familyshare.app.ui.screens.onboarding.OnboardingScreen

@Composable
fun AppNavHost(startGroupInvite: String? = null) {
    val nav = rememberNavController()
    val start = if (startGroupInvite != null) Dest.JoinGroup.route else Dest.Onboarding.route

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(300)) },
        exitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(300)) },
        popEnterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(300)) },
        popExitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(300)) },
    ) {
        composable(Dest.Onboarding.route) {
            OnboardingScreen(onGetStarted = {
                nav.navigate(Dest.Groups.route) {
                    popUpTo(Dest.Onboarding.route) { inclusive = true }
                }
            })
        }

        composable(Dest.Groups.route) {
            GroupsScreen(
                onCreateGroup = { nav.navigate(Dest.CreateGroup.route) },
                onJoinGroup = { nav.navigate(Dest.JoinGroup.route) },
                onOpenGroup = { id -> nav.navigate(Dest.Catalog.build(id)) },
            )
        }

        composable(Dest.CreateGroup.route) {
            CreateGroupScreen(
                onBack = { nav.popBackStack() },
                onCreated = { id ->
                    nav.navigate(Dest.GroupQr.build(id)) { popUpTo(Dest.Groups.route) }
                },
            )
        }

        composable(Dest.JoinGroup.route) {
            JoinGroupScreen(
                onBack = { nav.popBackStack() },
                inviteLink = startGroupInvite,
                onJoined = { id ->
                    nav.navigate(Dest.Catalog.build(id)) { popUpTo(Dest.Groups.route) }
                },
            )
        }

        composable(
            route = Dest.GroupQr.route,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("groupId").orEmpty()
            GroupQrScreen(
                groupId = id,
                onBack = { nav.popBackStack() },
                onOpenGroup = { gid -> nav.navigate(Dest.Catalog.build(gid)) { popUpTo(Dest.Groups.route) } },
            )
        }

        composable(
            route = Dest.Catalog.route,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("groupId").orEmpty()
            GroupCatalogScreen(
                groupId = id,
                onBack = { nav.popBackStack() },
                onInvite = { gid -> nav.navigate(Dest.GroupQr.build(gid)) },
                onManage = { gid -> nav.navigate(Dest.Manage.build(gid)) },
            )
        }

        composable(
            route = Dest.Manage.route,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("groupId").orEmpty()
            GroupManageScreen(
                groupId = id,
                onBack = { nav.popBackStack() },
                onShareInvite = { gid -> nav.navigate(Dest.GroupQr.build(gid)) },
                onLeft = {
                    nav.navigate(Dest.Groups.route) {
                        popUpTo(Dest.Groups.route) { inclusive = true }
                    }
                },
            )
        }
    }
}
