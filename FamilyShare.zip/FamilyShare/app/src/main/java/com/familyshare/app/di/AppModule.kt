package com.familyshare.app.di

import android.content.Context
import com.familyshare.app.data.repository.GroupRepository
import com.familyshare.app.p2p.LanGroupNetwork
import com.familyshare.app.p2p.RendezvousClient
import com.familyshare.app.p2p.WebRtcManager

/**
 * Conteneur de dépendances minimal (sans librairie de DI).
 * Pour un projet plus gros, remplacez par Hilt.
 */
object AppModule {

    val repository: GroupRepository by lazy { GroupRepository.get() }

    // Réseau de groupe sans serveur (découverte locale + service de fichiers).
    @Volatile private var lan: LanGroupNetwork? = null
    fun lanNetwork(context: Context): LanGroupNetwork =
        lan ?: synchronized(this) {
            lan ?: LanGroupNetwork(context.applicationContext).also { lan = it }
        }

    // Pont 1-à-1 pour un membre distant, sans serveur (optionnel).
    @Volatile private var webRtc: WebRtcManager? = null
    fun webRtcManager(context: Context): WebRtcManager =
        webRtc ?: synchronized(this) {
            webRtc ?: WebRtcManager(context.applicationContext).also { webRtc = it }
        }

    // Client du serveur de rendez-vous : mise en relation des membres distants.
    fun rendezvousClient(): RendezvousClient = RendezvousClient()
}
