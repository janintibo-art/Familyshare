package com.familyshare.app

// Configuration de l'application.
//
// Renseignez ici l'URL wss de votre serveur de rendez-vous déployé
// (voir le fichier server/README.md). Elle est encodée dans le QR de groupe,
// pour que tous les membres rejoignent le même point de rendez-vous et
// puissent se connecter même à distance.
//
// Laissez la valeur null pour rester en mode 100 % local : découverte
// automatique sur le même Wi-Fi uniquement, sans serveur.
object AppConfig {
    val RENDEZVOUS_URL: String? = "wss://VOTRE-SERVEUR.onrender.com"
}
