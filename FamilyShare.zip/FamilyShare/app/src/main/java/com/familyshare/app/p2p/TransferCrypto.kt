package com.familyshare.app.p2p

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Chiffrement du transfert de fichiers sur le réseau local.
 *
 * La clé AES-256 est dérivée du secret du groupe (SHA-256), donc seuls les membres
 * qui possèdent le secret peuvent déchiffrer. Le mode CTR permet de chiffrer/déchiffrer
 * en flux, sans mettre tout le fichier en mémoire (important pour les vidéos).
 *
 * Format envoyé sur le fil pour `/file` : [16 octets d'IV][octets chiffrés en CTR].
 *
 * Remarque honnête : CTR assure la **confidentialité** (protège d'une écoute passive
 * du Wi-Fi), mais pas l'authentification d'un attaquant actif. L'accès reste par
 * ailleurs filtré par le secret du groupe côté serveur.
 */
object TransferCrypto {

    const val IV_LEN = 16

    private fun keyFor(secret: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256").digest(secret.toByteArray(Charsets.UTF_8))
        return SecretKeySpec(digest, "AES")
    }

    /** Côté serveur : nouvel IV aléatoire + Cipher en mode chiffrement. */
    fun newEncryptCipher(secret: String): Pair<ByteArray, Cipher> {
        val iv = ByteArray(IV_LEN).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keyFor(secret), IvParameterSpec(iv))
        return iv to cipher
    }

    /** Côté client : Cipher en mode déchiffrement à partir de l'IV reçu. */
    fun decryptCipher(secret: String, iv: ByteArray): Cipher {
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, keyFor(secret), IvParameterSpec(iv))
        return cipher
    }
}
