package com.familyshare.app.p2p

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.util.Base64
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.math.abs

/** Rôle d'un ticket : l'hôte émet une OFFER, l'invité répond par une ANSWER. */
enum class TicketRole { OFFER, ANSWER }

/**
 * « Ticket de connexion » : tout ce qu'il faut pour établir le lien WebRTC,
 * empaqueté dans un QR code ou un lien. C'est CE ticket qui remplace le serveur
 * de signalisation : on l'échange via la messagerie habituelle (SMS, WhatsApp…)
 * ou, en personne / sur le même Wi-Fi, en scannant le QR.
 *
 * [sdp] contient la description de session WebRTC AVEC ses candidats ICE déjà
 * collectés (mode « non-trickle »), ce qui permet un échange en un seul message.
 */
@Serializable
data class ConnectionTicket(
    val role: TicketRole,
    val sdp: String,
    val shareId: String,
    val shareName: String,
    val peerName: String,
)

/**
 * Signalisation HORS-LIGNE, sans aucun serveur.
 *
 * Encodage : JSON → gzip → Base64 URL-safe → lien `familyshare://connect?t=…`
 * (ou QR code). La compression gzip est essentielle car un SDP est un texte
 * très répétitif : on tient ainsi dans un QR code.
 */
object ManualSignaling {
    const val SCHEME = "familyshare"
    const val HOST = "connect"
    private const val PARAM = "t"

    private val json = Json { ignoreUnknownKeys = true }
    private val b64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    /** Sérialise + compresse + encode un ticket (payload nu, sans le préfixe de lien). */
    fun encodeToPayload(ticket: ConnectionTicket): String {
        val raw = json.encodeToString(ticket).toByteArray(Charsets.UTF_8)
        val gz = ByteArrayOutputStream().also { GZIPOutputStream(it).use { z -> z.write(raw) } }.toByteArray()
        return Base64.encodeToString(gz, b64)
    }

    fun decodePayload(payload: String): ConnectionTicket? = runCatching {
        val gz = Base64.decode(payload.trim(), b64)
        val raw = GZIPInputStream(ByteArrayInputStream(gz)).use { it.readBytes() }
        json.decodeFromString<ConnectionTicket>(String(raw, Charsets.UTF_8))
    }.getOrNull()

    /** Lien profond complet, partageable par SMS / messagerie. */
    fun encodeToLink(ticket: ConnectionTicket): String =
        "$SCHEME://$HOST?$PARAM=${encodeToPayload(ticket)}"

    /** Décode un ticket depuis un lien (ou un payload nu collé tel quel). */
    fun decodeFromLink(link: String): ConnectionTicket? {
        val trimmed = link.trim()
        val payload = runCatching { Uri.parse(trimmed).getQueryParameter(PARAM) }.getOrNull()
            ?: if (trimmed.contains("$PARAM=")) trimmed.substringAfter("$PARAM=") else trimmed
        return decodePayload(payload)
    }

    /**
     * Code de vérification à 6 chiffres dérivé du SDP de l'offre. Il est IDENTIQUE
     * chez l'hôte et l'invité : s'ils voient le même code, ils sont bien en train
     * de se connecter l'un à l'autre (protection anti-interception, façon « numéro
     * de sécurité » de Signal).
     */
    fun verificationCode(offerSdp: String): String {
        var h = 1125899906842597L
        for (c in offerSdp) h = 31 * h + c.code
        val n = (abs(h) % 1_000_000L).toString().padStart(6, '0')
        return "${n.substring(0, 3)} ${n.substring(3)}"
    }

    /**
     * Génère le QR code d'un contenu (typiquement un lien de ticket).
     * Correction d'erreur volontairement basse (L) pour maximiser la capacité,
     * car les tickets peuvent atteindre 1 à 2 Ko. Peut lever une exception si le
     * contenu est trop volumineux : dans ce cas, on retombe sur le partage du lien.
     */
    fun qrBitmap(content: String, sizePx: Int = 640): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
            EncodeHintType.MARGIN to 1,
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val w = matrix.width
        val h = matrix.height
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        for (x in 0 until w) {
            for (y in 0 until h) {
                bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }
}
