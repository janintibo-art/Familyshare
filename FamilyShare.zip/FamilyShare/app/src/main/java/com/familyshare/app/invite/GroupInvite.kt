package com.familyshare.app.invite

import android.net.Uri
import android.util.Base64
import com.familyshare.app.data.model.GroupType
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Informations encodées dans le QR / lien d'invitation à un groupe. Le [secret]
 * contrôle l'accès : un appareil ne répond qu'aux membres présentant le bon
 * secret du groupe.
 */
@Serializable
data class GroupInvite(
    val id: String,
    val name: String,
    val type: GroupType,
    val secret: String,
    val server: String? = null, // URL wss:// du serveur de rendez-vous (null = local seul)
)

/** Encode/décode un [GroupInvite] vers un lien `familyshare://group?g=…` (et QR). */
object GroupInviteCodec {
    const val SCHEME = "familyshare"
    const val HOST = "group"
    private const val PARAM = "g"

    private val json = Json { ignoreUnknownKeys = true }
    private val b64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    fun encodeToLink(invite: GroupInvite): String {
        val raw = json.encodeToString(invite).toByteArray(Charsets.UTF_8)
        val gz = ByteArrayOutputStream().also { GZIPOutputStream(it).use { z -> z.write(raw) } }.toByteArray()
        return "$SCHEME://$HOST?$PARAM=${Base64.encodeToString(gz, b64)}"
    }

    fun decode(link: String): GroupInvite? = runCatching {
        val t = link.trim()
        val payload = runCatching { Uri.parse(t).getQueryParameter(PARAM) }.getOrNull()
            ?: if (t.contains("$PARAM=")) t.substringAfter("$PARAM=") else t
        val gz = Base64.decode(payload, b64)
        val raw = GZIPInputStream(ByteArrayInputStream(gz)).use { it.readBytes() }
        json.decodeFromString<GroupInvite>(String(raw, Charsets.UTF_8))
    }.getOrNull()
}
