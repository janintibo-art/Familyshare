package com.familyshare.app.ui.navigation

/** Routes de navigation de l'application. */
sealed class Dest(val route: String) {
    data object Onboarding : Dest("onboarding")
    data object Groups : Dest("groups")
    data object CreateGroup : Dest("create_group")
    data object JoinGroup : Dest("join_group")

    data object GroupQr : Dest("group_qr/{groupId}") {
        fun build(groupId: String) = "group_qr/$groupId"
    }
    data object Catalog : Dest("catalog/{groupId}") {
        fun build(groupId: String) = "catalog/$groupId"
    }
    data object Manage : Dest("manage/{groupId}") {
        fun build(groupId: String) = "manage/$groupId"
    }
}
