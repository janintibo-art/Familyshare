package com.familyshare.app.p2p

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.data.model.TransferProgress
import com.familyshare.app.data.model.TransferState
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

/**
 * Transfert distant via WebRTC — pour un membre hors du réseau local. Le
 * signaling (offre / réponse / ICE) est relayé par le serveur de rendez-vous
 * (voir [RendezvousClient] / [GroupSession]) ; une fois la connexion établie, le
 * fichier transite **directement** sur un DataChannel (chiffré DTLS), jamais par
 * le serveur.
 *
 * Protocole sur le canal « files » :
 *   - le DEMANDEUR ouvre le canal et envoie {"req": "<fileId>"} ;
 *   - le PROPRIÉTAIRE répond par un en-tête {"name","size","mime"}, puis des
 *     trames binaires de [CHUNK_SIZE] octets, puis {"eof": true} ;
 *   - le DEMANDEUR réassemble et enregistre dans la galerie.
 *
 * ⚠️ WebRTC se valide en conditions réelles (deux appareils, traversée de NAT).
 */
class WebRtcManager(private val context: Context) {

    private var filesProvider: () -> List<SharedFile> = { emptyList() }
    private var sendSignal: (toPeerId: String, data: JSONObject) -> Unit = { _, _ -> }
    private var onProgress: (TransferProgress) -> Unit = {}

    private var factory: PeerConnectionFactory? = null
    private val peers = ConcurrentHashMap<String, PeerCtx>()

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
    )

    /** Branche les dépendances de la session (fichiers à servir, envoi du signaling, progression). */
    fun attach(
        filesProvider: () -> List<SharedFile>,
        sendSignal: (String, JSONObject) -> Unit,
        onProgress: (TransferProgress) -> Unit,
    ) {
        this.filesProvider = filesProvider
        this.sendSignal = sendSignal
        this.onProgress = onProgress
        ensureFactory()
    }

    private fun ensureFactory() {
        if (factory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    /** Côté DEMANDEUR : ouvre une connexion vers le propriétaire et réclame le fichier. */
    fun requestDownload(ownerId: String, file: SharedFile) {
        ensureFactory()
        onProgress(TransferProgress(file.id, file.name, 0, file.sizeBytes, TransferState.TRANSFERRING))
        val ctx = createPeer(ownerId)
        ctx.pendingFile = file
        val dc = ctx.pc?.createDataChannel("files", DataChannel.Init())
        ctx.channel = dc
        dc?.registerObserver(channelObserver(ctx))
        ctx.pc?.createOffer(object : SdpAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc ?: return
                ctx.pc?.setLocalDescription(SdpAdapter(), desc)
                sendSignal(ownerId, sdpJson(desc))
            }
        }, MediaConstraints())
    }

    /** Réception d'un message de signaling destiné à ce pair. */
    fun onSignal(fromId: String, data: JSONObject) {
        ensureFactory()
        when (data.optString("kind")) {
            "sdp" -> {
                val type = data.optString("type")
                val sdp = SessionDescription(
                    if (type == "offer") SessionDescription.Type.OFFER else SessionDescription.Type.ANSWER,
                    data.optString("sdp"),
                )
                if (type == "offer") {
                    val ctx = createPeer(fromId)
                    ctx.pc?.setRemoteDescription(object : SdpAdapter() {
                        override fun onSetSuccess() {
                            ctx.pc?.createAnswer(object : SdpAdapter() {
                                override fun onCreateSuccess(desc: SessionDescription?) {
                                    desc ?: return
                                    ctx.pc?.setLocalDescription(SdpAdapter(), desc)
                                    sendSignal(fromId, sdpJson(desc))
                                }
                            }, MediaConstraints())
                        }
                    }, sdp)
                } else {
                    peers[fromId]?.pc?.setRemoteDescription(SdpAdapter(), sdp)
                }
            }
            "ice" -> {
                val c = data.optJSONObject("candidate") ?: return
                peers[fromId]?.pc?.addIceCandidate(
                    IceCandidate(c.optString("mid"), c.optInt("index"), c.optString("sdp"))
                )
            }
        }
    }

    private fun createPeer(peerId: String): PeerCtx {
        peers[peerId]?.let { return it }
        val ctx = PeerCtx(peerId)
        ctx.pc = factory?.createPeerConnection(PeerConnection.RTCConfiguration(iceServers), peerObserver(ctx))
        peers[peerId] = ctx
        return ctx
    }

    private fun peerObserver(ctx: PeerCtx) = object : PeerConnection.Observer {
        override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(p0: Boolean) {}
        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(p0: IceCandidate?) {
            p0 ?: return
            val cand = JSONObject().put("mid", p0.sdpMid).put("index", p0.sdpMLineIndex).put("sdp", p0.sdp)
            sendSignal(ctx.peerId, JSONObject().put("kind", "ice").put("candidate", cand))
        }
        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
        override fun onAddStream(p0: MediaStream?) {}
        override fun onRemoveStream(p0: MediaStream?) {}
        override fun onDataChannel(p0: DataChannel?) {
            ctx.channel = p0
            p0?.registerObserver(channelObserver(ctx))
        }
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
    }

    private fun channelObserver(ctx: PeerCtx) = object : DataChannel.Observer {
        override fun onBufferedAmountChange(previousAmount: Long) {}
        override fun onStateChange() {
            val dc = ctx.channel ?: return
            if (dc.state() == DataChannel.State.OPEN) {
                ctx.pendingFile?.let { f ->
                    sendText(dc, JSONObject().put("req", f.id))
                }
            }
        }
        override fun onMessage(buffer: DataChannel.Buffer?) {
            buffer ?: return
            val bytes = ByteArray(buffer.data.remaining())
            buffer.data.get(bytes)
            if (buffer.binary) {
                ctx.receiver?.write(bytes)
            } else {
                handleControl(ctx, String(bytes))
            }
        }
    }

    private fun handleControl(ctx: PeerCtx, text: String) {
        val json = runCatching { JSONObject(text) }.getOrNull() ?: return
        when {
            json.has("req") -> {
                val id = json.optString("req")
                filesProvider().firstOrNull { it.id == id }?.let { sendFile(ctx, it) }
            }
            json.has("name") -> {
                ctx.receiver = Receiver(
                    context = context,
                    fileId = ctx.pendingFile?.id ?: json.optString("name"),
                    name = json.optString("name"),
                    size = json.optLong("size"),
                    mime = json.optString("mime", "application/octet-stream"),
                    onProgress = onProgress,
                )
            }
            json.has("eof") -> {
                ctx.receiver?.finish()
                ctx.receiver = null
                close(ctx.peerId)
            }
        }
    }

    private fun sendFile(ctx: PeerCtx, file: SharedFile) {
        val dc = ctx.channel ?: return
        Thread {
            try {
                sendText(dc, JSONObject().put("name", file.name).put("size", file.sizeBytes).put("mime", file.mimeType))
                context.contentResolver.openInputStream(Uri.parse(file.uri))?.use { input ->
                    val buf = ByteArray(CHUNK_SIZE)
                    var read: Int
                    while (input.read(buf).also { read = it } != -1) {
                        while (dc.bufferedAmount() > BUFFER_THRESHOLD) Thread.sleep(5)
                        val chunk = if (read == buf.size) buf.copyOf() else buf.copyOf(read)
                        dc.send(DataChannel.Buffer(ByteBuffer.wrap(chunk), true))
                    }
                }
                sendText(dc, JSONObject().put("eof", true))
            } catch (e: Exception) {
                // transfert interrompu
            }
        }.start()
    }

    private fun sendText(dc: DataChannel, json: JSONObject) {
        dc.send(DataChannel.Buffer(ByteBuffer.wrap(json.toString().toByteArray()), false))
    }

    fun close(peerId: String) {
        peers.remove(peerId)?.let { ctx ->
            runCatching { ctx.channel?.close() }
            runCatching { ctx.pc?.close() }
        }
    }

    fun close() {
        peers.keys.toList().forEach { close(it) }
    }

    private fun sdpJson(desc: SessionDescription) = JSONObject()
        .put("kind", "sdp")
        .put("type", if (desc.type == SessionDescription.Type.OFFER) "offer" else "answer")
        .put("sdp", desc.description)

    private class PeerCtx(val peerId: String) {
        var pc: PeerConnection? = null
        var channel: DataChannel? = null
        var pendingFile: SharedFile? = null
        var receiver: Receiver? = null
    }

    /** Réassemble un fichier reçu et l'enregistre dans la galerie (ou le dossier de l'app). */
    private class Receiver(
        private val context: Context,
        private val fileId: String,
        private val name: String,
        private val size: Long,
        private val mime: String,
        private val onProgress: (TransferProgress) -> Unit,
    ) {
        private var out: OutputStream? = null
        private var uri: Uri? = null
        private var received = 0L
        private var failed = false
        private var opened = false

        private fun ensureOpen() {
            if (opened) return
            opened = true
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = context.contentResolver
                    val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
                    val (collection, rel) = when {
                        mime.startsWith("image/") -> MediaStore.Images.Media.getContentUri(vol) to "${Environment.DIRECTORY_PICTURES}/FamilyShare"
                        mime.startsWith("video/") -> MediaStore.Video.Media.getContentUri(vol) to "${Environment.DIRECTORY_MOVIES}/FamilyShare"
                        mime.startsWith("audio/") -> MediaStore.Audio.Media.getContentUri(vol) to "${Environment.DIRECTORY_MUSIC}/FamilyShare"
                        else -> MediaStore.Downloads.getContentUri(vol) to "${Environment.DIRECTORY_DOWNLOADS}/FamilyShare"
                    }
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    uri = resolver.insert(collection, values)
                    out = uri?.let { resolver.openOutputStream(it) }
                } else {
                    val dir = File(context.getExternalFilesDir(null), "FamilyShare").apply { mkdirs() }
                    val f = File(dir, name)
                    uri = Uri.fromFile(f)
                    out = FileOutputStream(f)
                }
            } catch (e: Exception) {
                failed = true
            }
        }

        fun write(bytes: ByteArray) {
            ensureOpen()
            val o = out ?: return
            try {
                o.write(bytes)
                received += bytes.size
                onProgress(TransferProgress(fileId, name, received, size, TransferState.TRANSFERRING))
            } catch (e: Exception) {
                failed = true
            }
        }

        fun finish() {
            runCatching { out?.flush(); out?.close() }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri != null && !failed) {
                runCatching {
                    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    context.contentResolver.update(uri!!, v, null, null)
                }
            }
            onProgress(
                TransferProgress(fileId, name, received, size, if (failed) TransferState.FAILED else TransferState.DONE, uri?.toString())
            )
        }
    }

    private open class SdpAdapter : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }

    companion object {
        const val CHUNK_SIZE = 16 * 1024
        const val BUFFER_THRESHOLD = 1 * 1024 * 1024L
    }
}
