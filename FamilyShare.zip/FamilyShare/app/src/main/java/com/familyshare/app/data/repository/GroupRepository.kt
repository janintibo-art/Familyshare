package com.familyshare.app.data.repository

import com.familyshare.app.data.model.Group
import com.familyshare.app.data.model.GroupMember
import com.familyshare.app.data.model.GroupType
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.data.model.TransferProgress
import com.familyshare.app.data.model.TransferState
import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID
import kotlin.random.Random

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "familyshare")
private val KEY_GROUPS = stringPreferencesKey("groups")
private val KEY_MYFILES = stringPreferencesKey("my_files")
private val KEY_DOWNLOADED = stringPreferencesKey("downloaded")

/**
 * Source de vérité de l'application.
 *
 * ⚠️ Démonstration : tout vit en mémoire pour que l'interface soit navigable
 * sans réseau. En production :
 *  - les groupes et MES fichiers partagés sont persistés via DataStore ;
 *  - le catalogue commun est construit en interrogeant chaque membre du groupe
 *    découvert sur le réseau via [com.familyshare.app.p2p.LanGroupNetwork] ;
 *  - mes fichiers partagés sont listés depuis le dossier SAF (DocumentFile).
 */
class GroupRepository private constructor() {

    private val _groups = MutableStateFlow(sampleGroups())
    val groups: StateFlow<List<Group>> = _groups.asStateFlow()

    /** Catalogue agrégé par groupe : tous les fichiers partagés par tous les membres. */
    private val _catalog = MutableStateFlow(sampleCatalog())
    val catalog: StateFlow<Map<String, List<SharedFile>>> = _catalog.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, TransferProgress>>(emptyMap())
    val downloads: StateFlow<Map<String, TransferProgress>> = _downloads.asStateFlow()

    /** Bibliothèque persistante des fichiers téléchargés (disponibles hors ligne). */
    private val _downloaded = MutableStateFlow<Map<String, List<SharedFile>>>(emptyMap())
    val downloaded: StateFlow<Map<String, List<SharedFile>>> = _downloaded.asStateFlow()

    private var appContext: Context? = null
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true }

    fun groupById(id: String): Group? = _groups.value.firstOrNull { it.id == id }
    fun catalogFor(id: String): List<SharedFile> = _catalog.value[id].orEmpty()
    fun myFilesIn(id: String): List<SharedFile> = catalogFor(id).filter { it.ownerId == ME_ID }

    fun createGroup(name: String, type: GroupType): Group {
        val g = Group(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { if (type == GroupType.FAMILY) "Ma famille" else "Mes amis" },
            type = type,
            secret = randomSecret(),
            members = listOf(GroupMember(ME_ID, "Moi", isMe = true, isOnline = true)),
        )
        _groups.update { listOf(g) + it }
        _catalog.update { it + (g.id to emptyList()) }
        saveGroups()
        return g
    }

    fun joinGroup(id: String, name: String, type: GroupType, secret: String): Group {
        _groups.value.firstOrNull { it.id == id }?.let { return it }
        val g = Group(
            id = id,
            name = name,
            type = type,
            secret = secret,
            members = listOf(GroupMember(ME_ID, "Moi", isMe = true, isOnline = true)),
        )
        _groups.update { listOf(g) + it }
        _catalog.update { it + (g.id to emptyList()) }
        saveGroups()
        return g
    }

    /** J'ajoute mes fichiers au pot commun du groupe (les autres pourront les piocher). */
    fun addMyFiles(groupId: String, files: List<SharedFile>) {
        _catalog.update { map ->
            map + (groupId to (map[groupId].orEmpty() + files).distinctBy { it.id })
        }
        saveMyFiles()
    }

    /** Quitte un groupe : le retire localement (les autres gardent le leur). */
    fun leaveGroup(groupId: String) {
        _groups.update { it.filterNot { g -> g.id == groupId } }
        _catalog.update { it - groupId }
        _downloaded.update { it - groupId }
        saveGroups()
        saveMyFiles()
        saveDownloaded()
    }

    /** Renomme un groupe (local). */
    fun renameGroup(groupId: String, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        _groups.update { list -> list.map { if (it.id == groupId) it.copy(name = clean) else it } }
        saveGroups()
    }

    /**
     * Retire un membre de MA vue du groupe (et ses fichiers du catalogue local).
     * Sans serveur, cela ne l'empêche pas de rejoindre à nouveau avec le lien :
     * pour l'exclure vraiment, régénérez le secret et repartagez l'invitation.
     */
    fun removeMember(groupId: String, memberId: String) {
        if (memberId == ME_ID) return
        _groups.update { list ->
            list.map { g ->
                if (g.id != groupId) g
                else g.copy(members = g.members.filterNot { it.id == memberId })
            }
        }
        _catalog.update { map ->
            map + (groupId to map[groupId].orEmpty().filterNot { it.ownerId == memberId })
        }
        saveGroups()
    }

    /**
     * Régénère le secret du groupe (nouvelle clé d'accès). L'ancienne invitation
     * cesse de fonctionner : il faut repartager le nouveau QR / lien aux membres.
     * Renvoie le nouveau secret, ou null si le groupe est introuvable.
     */
    fun regenerateSecret(groupId: String): String? {
        val newSecret = randomSecret()
        var applied = false
        _groups.update { list ->
            list.map { g ->
                if (g.id != groupId) g else { applied = true; g.copy(secret = newSecret) }
            }
        }
        if (!applied) return null
        saveGroups()
        return newSecret
    }

    fun markDownload(file: SharedFile, state: TransferState, done: Long = 0L) {
        setDownload(TransferProgress(file.id, file.name, done, file.sizeBytes, state))
    }

    /** Applique une progression de transfert (émise par la couche réseau) et calcule la vitesse. */
    fun setDownload(progress: TransferProgress) {
        _downloads.update { map ->
            val prev = map[progress.fileId]
            map + (progress.fileId to progress.copy(bytesPerSec = computeSpeed(prev, progress)))
        }
        if (progress.state == TransferState.DONE && progress.outputUri != null) {
            recordDownloaded(progress)
        }
    }

    /** Enregistre un fichier terminé dans la bibliothèque hors ligne (avec son URI local). */
    private fun recordDownloaded(progress: TransferProgress) {
        val uri = progress.outputUri ?: return
        for ((gid, files) in _catalog.value) {
            val src = files.firstOrNull { it.id == progress.fileId } ?: continue
            val entry = src.copy(uri = uri)
            _downloaded.update { map ->
                map + (gid to (map[gid].orEmpty().filterNot { it.id == entry.id } + entry))
            }
            saveDownloaded()
            return
        }
    }

    fun downloadedFor(id: String): List<SharedFile> = _downloaded.value[id].orEmpty()

    /** Supprime un téléchargement : efface le fichier local (libère l'espace) et l'oublie. */
    fun removeDownload(groupId: String, fileId: String) {
        _downloaded.value[groupId]?.firstOrNull { it.id == fileId }?.let { deleteLocalFile(it.uri) }
        _downloaded.update { map ->
            val list = map[groupId].orEmpty().filterNot { it.id == fileId }
            if (list.isEmpty()) map - groupId else map + (groupId to list)
        }
        clearDownload(fileId)
        saveDownloaded()
    }

    /** Supprime tous les téléchargements d'un groupe (libère l'espace). */
    fun clearDownloads(groupId: String) {
        _downloaded.value[groupId]?.forEach {
            deleteLocalFile(it.uri)
            clearDownload(it.id)
        }
        _downloaded.update { it - groupId }
        saveDownloaded()
    }

    private fun deleteLocalFile(uriStr: String) {
        val ctx = appContext ?: return
        runCatching {
            val uri = android.net.Uri.parse(uriStr)
            when (uri.scheme) {
                "content" -> ctx.contentResolver.delete(uri, null, null)
                "file" -> uri.path?.let { java.io.File(it).delete() }
                else -> {}
            }
        }
    }

    /** Retire un transfert du suivi (annulation). */
    fun clearDownload(fileId: String) {
        _downloads.update { it - fileId }
    }

    private fun computeSpeed(prev: TransferProgress?, cur: TransferProgress): Long {
        if (prev == null) return cur.bytesPerSec
        val dt = cur.timestamp - prev.timestamp
        if (dt <= 0 || cur.bytesTransferred <= prev.bytesTransferred) return prev.bytesPerSec
        val instant = (cur.bytesTransferred - prev.bytesTransferred) * 1000 / dt
        // Lissage exponentiel pour une valeur stable.
        return if (prev.bytesPerSec <= 0) instant else (prev.bytesPerSec * 7 + instant * 3) / 10
    }

    // --- Mises à jour en direct, alimentées par la session de groupe ---

    /** Fusionne des membres reçus en direct (les marque en ligne, ajoute les inconnus). */
    fun applyMembers(groupId: String, incoming: List<GroupMember>) {
        if (incoming.isEmpty()) return
        _groups.update { list ->
            list.map { g ->
                if (g.id != groupId) return@map g
                val byId = g.members.associateBy { it.id }.toMutableMap()
                incoming.forEach { m ->
                    val ex = byId[m.id]
                    byId[m.id] = ex?.copy(
                        isOnline = true,
                        endpoint = m.endpoint ?: ex.endpoint,
                    ) ?: m.copy(isOnline = true)
                }
                g.copy(members = byId.values.toList())
            }
        }
    }

    fun setMemberOnline(groupId: String, memberId: String, online: Boolean) {
        _groups.update { list ->
            list.map { g ->
                if (g.id != groupId) g
                else g.copy(members = g.members.map { if (it.id == memberId) it.copy(isOnline = online) else it })
            }
        }
    }

    /** Remplace les fichiers d'un propriétaire dans le catalogue d'un groupe. */
    fun applyCatalogFromOwner(groupId: String, ownerId: String, ownerName: String, files: List<SharedFile>) {
        val normalized = files.map { it.copy(ownerId = ownerId, ownerName = ownerName) }
        _catalog.update { map ->
            val others = map[groupId].orEmpty().filter { it.ownerId != ownerId }
            map + (groupId to (others + normalized))
        }
    }

    // --- Persistance (DataStore) : groupes + MES fichiers partagés ---

    /** À appeler une fois au démarrage (depuis l'Application) pour restaurer l'état. */
    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        ioScope.launch { load() }
    }

    private suspend fun load() {
        val ctx = appContext ?: return
        val prefs = runCatching { ctx.dataStore.data.first() }.getOrNull() ?: return
        prefs[KEY_GROUPS]?.let { raw ->
            runCatching { json.decodeFromString<List<Group>>(raw) }.getOrNull()?.let { _groups.value = it }
        }
        val savedMine = prefs[KEY_MYFILES]?.let { raw ->
            runCatching { json.decodeFromString<Map<String, List<SharedFile>>>(raw) }.getOrNull()
        }
        if (savedMine != null) {
            savedMine.forEach { (gid, files) -> applyCatalogFromOwner(gid, ME_ID, "Moi", files) }
        } else {
            // Premier lancement : on enregistre l'état initial pour les fois suivantes.
            saveGroups()
            saveMyFiles()
        }
        prefs[KEY_DOWNLOADED]?.let { raw ->
            runCatching { json.decodeFromString<Map<String, List<SharedFile>>>(raw) }.getOrNull()?.let { _downloaded.value = it }
        }
    }

    private fun saveGroups() {
        val ctx = appContext ?: return
        val snapshot = _groups.value.map { g ->
            g.copy(members = g.members.map { it.copy(isOnline = false, endpoint = null) })
        }
        val data = runCatching { json.encodeToString(snapshot) }.getOrNull() ?: return
        ioScope.launch { runCatching { ctx.dataStore.edit { it[KEY_GROUPS] = data } } }
    }

    private fun saveMyFiles() {
        val ctx = appContext ?: return
        val mine = _catalog.value
            .mapValues { (_, files) -> files.filter { it.ownerId == ME_ID } }
            .filterValues { it.isNotEmpty() }
        val data = runCatching { json.encodeToString(mine) }.getOrNull() ?: return
        ioScope.launch { runCatching { ctx.dataStore.edit { it[KEY_MYFILES] = data } } }
    }

    private fun saveDownloaded() {
        val ctx = appContext ?: return
        val data = runCatching { json.encodeToString(_downloaded.value) }.getOrNull() ?: return
        ioScope.launch { runCatching { ctx.dataStore.edit { it[KEY_DOWNLOADED] = data } } }
    }

    companion object {
        const val ME_ID = "me"

        @Volatile private var instance: GroupRepository? = null
        fun get(): GroupRepository =
            instance ?: synchronized(this) { instance ?: GroupRepository().also { instance = it } }
    }
}

private fun randomSecret(): String {
    val pool = "abcdefghijklmnopqrstuvwxyz0123456789"
    return (1..16).map { pool[Random.nextInt(pool.length)] }.joinToString("")
}

// ---------------------------------------------------------------------------
// Données d'exemple (à supprimer une fois le réseau branché)
// ---------------------------------------------------------------------------

private fun sampleGroups(): List<Group> = listOf(
    Group(
        id = "g-famille", name = "Ma famille", type = GroupType.FAMILY, secret = "demofam0000000001",
        members = listOf(
            GroupMember("me", "Moi", isMe = true, isOnline = true),
            GroupMember("maman", "Maman", isOnline = true, endpoint = "192.168.1.21:8765"),
            GroupMember("papa", "Papa", isOnline = false),
            GroupMember("lea", "Léa", isOnline = true, endpoint = "192.168.1.34:8765"),
        ),
    ),
    Group(
        id = "g-amis", name = "Les copains", type = GroupType.FRIENDS, secret = "demoami0000000002",
        members = listOf(
            GroupMember("me", "Moi", isMe = true, isOnline = true),
            GroupMember("thomas", "Thomas", isOnline = true, endpoint = "192.168.1.40:8765"),
            GroupMember("sarah", "Sarah", isOnline = false),
        ),
    ),
)

private fun sampleCatalog(): Map<String, List<SharedFile>> {
    fun jpg(id: String, n: String, owner: Pair<String, String>, mb: Long) =
        SharedFile(id, "$n.jpg", mb * 1_000_000, "image/jpeg", "content://demo/$n", owner.first, owner.second)

    val maman = "maman" to "Maman"
    val papa = "papa" to "Papa"
    val lea = "lea" to "Léa"
    val thomas = "thomas" to "Thomas"
    val sarah = "sarah" to "Sarah"

    return mapOf(
        "g-famille" to listOf(
            jpg("f1", "plage_coucher_soleil", maman, 3),
            jpg("f2", "diner_crepes", maman, 2),
            SharedFile("f3", "feu_artifice.mp4", 84_000_000, "video/mp4", "content://demo/feu", papa.first, papa.second),
            SharedFile("f4", "recettes_famille.pdf", 1_200_000, "application/pdf", "content://demo/rec", papa.first, papa.second),
            jpg("f5", "famille_rando", lea, 4),
            SharedFile("f6", "premiers_pas_bebe.mov", 120_000_000, "video/quicktime", "content://demo/bebe", lea.first, lea.second),
        ),
        "g-amis" to listOf(
            jpg("a1", "rando_montagne", thomas, 5),
            SharedFile("a2", "concert.mp4", 230_000_000, "video/mp4", "content://demo/concert", thomas.first, thomas.second),
            jpg("a3", "barbecue", sarah, 3),
        ),
    )
}

/** Met en forme une taille en octets de façon lisible. */
fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes o"
    val units = listOf("Ko", "Mo", "Go", "To")
    var value = bytes / 1024.0
    var i = 0
    while (value >= 1024 && i < units.lastIndex) { value /= 1024; i++ }
    return String.format("%.1f %s", value, units[i])
}
