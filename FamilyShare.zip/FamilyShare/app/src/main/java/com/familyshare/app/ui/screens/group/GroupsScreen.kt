package com.familyshare.app.ui.screens.group

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.FamilyRestroom
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyshare.app.data.model.Group
import com.familyshare.app.data.model.GroupType
import com.familyshare.app.data.repository.formatBytes
import com.familyshare.app.di.AppModule
import com.familyshare.app.ui.components.GradientBackground
import com.familyshare.app.ui.theme.Coral
import com.familyshare.app.ui.theme.Peach
import com.familyshare.app.ui.theme.Teal

@Composable
fun GroupsScreen(
    onCreateGroup: () -> Unit,
    onJoinGroup: () -> Unit,
    onOpenGroup: (String) -> Unit,
) {
    val repo = AppModule.repository
    val groups by repo.groups.collectAsState()
    val catalog by repo.catalog.collectAsState()
    val downloadedMap by repo.downloaded.collectAsState()
    val fsBytes = downloadedMap.values.sumOf { list -> list.sumOf { it.sizeBytes } }
    val ctx = LocalContext.current
    // Total/libre du volume hôte ; re-calculé quand les téléchargements changent (l'espace libéré se voit).
    val (totalBytes, freeBytes) = remember(downloadedMap) {
        runCatching {
            val stat = android.os.StatFs(ctx.filesDir.absolutePath)
            stat.totalBytes to stat.availableBytes
        }.getOrDefault(0L to 0L)
    }

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateGroup,
                containerColor = Coral,
                contentColor = Color.White,
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("Créer un groupe", fontWeight = FontWeight.SemiBold) },
            )
        },
    ) { inner ->
        GradientBackground {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 20.dp, end = 20.dp,
                    top = inner.calculateTopPadding() + 16.dp,
                    bottom = inner.calculateBottomPadding() + 96.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item { Header(onJoinGroup) }
                item { StorageIndicator(totalBytes = totalBytes, freeBytes = freeBytes, fsBytes = fsBytes) }

                if (groups.isEmpty()) {
                    item { EmptyState() }
                } else {
                    item {
                        Text(
                            "Mes groupes",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
                        )
                    }
                    items(groups, key = { it.id }) { group ->
                        GroupCard(
                            group = group,
                            fileCount = catalog[group.id]?.size ?: 0,
                            onClick = { onOpenGroup(group.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(onJoinGroup: () -> Unit) {
    Column {
        Spacer(Modifier.height(8.dp))
        Text(
            "Bonjour 👋",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Vos groupes de partage",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = onJoinGroup,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
        ) {
            Icon(Icons.Rounded.QrCodeScanner, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Rejoindre un groupe", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GroupCard(group: Group, fileCount: Int, onClick: () -> Unit) {
    val accent = if (group.type == GroupType.FAMILY) Coral else Teal
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (group.type == GroupType.FAMILY) Icons.Rounded.FamilyRestroom else Icons.Rounded.Groups,
                contentDescription = null,
                tint = accent,
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                group.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.People,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    "${group.members.size} membres • $fileCount fichiers",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Icon(
            Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Peach.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.Groups,
                contentDescription = null,
                tint = Coral,
                modifier = Modifier.size(44.dp),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("Aucun groupe pour l'instant", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            "Créez un groupe Famille ou Amis, partagez le QR, et tout le monde verra les fichiers mis en commun.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Indicateur d'espace de stockage : barre segmentée autres / FamilyShare / libre. */
@Composable
private fun StorageIndicator(totalBytes: Long, freeBytes: Long, fsBytes: Long) {
    if (totalBytes <= 0L) return
    val used = (totalBytes - freeBytes).coerceIn(0L, totalBytes)
    val fs = fsBytes.coerceIn(0L, used)
    val otherUsed = (used - fs).coerceAtLeast(0L)
    val freePct = (freeBytes.toFloat() / totalBytes * 100f).toInt().coerceIn(0, 100)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Storage, contentDescription = null, tint = Coral, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Stockage de l'appareil", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("$freePct% libre", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp)),
        ) {
            if (otherUsed > 0L) {
                Box(
                    modifier = Modifier
                        .weight(otherUsed.toFloat())
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                )
            }
            if (fs > 0L) {
                Box(
                    modifier = Modifier
                        .weight(fs.toFloat())
                        .fillMaxHeight()
                        .background(Coral),
                )
            }
            if (freeBytes > 0L) {
                Box(
                    modifier = Modifier
                        .weight(freeBytes.toFloat())
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Coral))
            Spacer(Modifier.width(6.dp))
            Text(
                "Téléchargements FamilyShare : ${formatBytes(fsBytes)}",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.weight(1f))
            Text(
                "${formatBytes(freeBytes)} libres / ${formatBytes(totalBytes)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
