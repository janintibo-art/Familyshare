package com.familyshare.app.p2p

import android.content.Context
import com.familyshare.app.AppConfig
import com.familyshare.app.data.model.Group
import com.familyshare.app.data.model.GroupMember
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.data.model.TransferState
import com.familyshare.app.data.repository.GroupRepository
import com.familyshare.app.di.AppModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Coordonne une session de groupe : relie découverte locale ([LanGroupNetwork]),
 * serveur de rendez-vous distant ([RendezvousClient]) et transfert WebRTC
 * ([WebRtcManager]), et pousse tout (membres en ligne, catalogue, progression)
 * dans [GroupRepository] pour que l'écran se mette à jour seul.
 */
class GroupSession(
    private val context: Context,
    private val group: Group,
) {
    private val repo: GroupRepository = AppModule.repository
    private val lan = AppModule.lanNetwork(context)
    private val webRtc = AppModule.webRtcManager(context)
    private val rendezvous: RendezvousClient? =
        if (AppConfig.RENDEZVOUS_URL != null) AppModule.rendezvousClient() else null

    private val me = GroupMember(GroupRepository.ME_ID, "Moi", isMe = true, isOnline = true)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val fetchedPeers = mutableSetOf<String>()
    private val cancellers = mutableMapOf<String, () -> Unit>()

    fun start() {
        // 1. Réseau local : publie le groupe, sert mes fichiers (lus en direct), découvre les pairs.
        lan.start(group, me) { repo.myFilesIn(group.id) }

        // WebRTC distant : fichiers à servir, envoi du signaling, progression.
        webRtc.attach(
            filesProvider = { repo.myFilesIn(group.id) },
            sendSignal = { to, data -> rendezvous?.sendSignal(to, data) },
            onProgress = { repo.setDownload(it) },
        )

        // À chaque pair local découvert : on le marque en ligne et on récupère son catalogue.
        scope.launch {
            lan.peers.collect { peers ->
                peers.forEach { p ->
                    repo.applyMembers(
                        group.id,
                        listOf(GroupMember(p.memberId, p.name, isOnline = true, endpoint = "${p.host}:${p.port}")),
                    )
                    if (fetchedPeers.add(p.serviceName.ifEmpty { p.memberId })) {
                        scope.launch {
                            val files = lan.fetchCatalog(p)
                            if (files.isNotEmpty()) repo.applyCatalogFromOwner(group.id, p.memberId, p.name, files)
                        }
                    }
                }
            }
        }

        // 2. Serveur de rendez-vous (si configuré) : membres + catalogue distants.
        val url = AppConfig.RENDEZVOUS_URL
        if (rendezvous != null && url != null) {
            rendezvous.connect(url, group, me, object : RendezvousClient.Listener {
                override fun onWelcome(members: List<GroupMember>, catalog: List<SharedFile>) {
                    repo.applyMembers(group.id, members)
                    catalog.groupBy { it.ownerId }.forEach { (owner, files) ->
                        repo.applyCatalogFromOwner(group.id, owner, files.firstOrNull()?.ownerName ?: owner, files)
                    }
                }

                override fun onPeerJoined(member: GroupMember) {
                    repo.applyMembers(group.id, listOf(member))
                }

                override fun onPeerLeft(memberId: String) {
                    repo.setMemberOnline(group.id, memberId, false)
                }

                override fun onSignal(fromMemberId: String, data: JSONObject) {
                    webRtc.onSignal(fromMemberId, data) // transfert distant WebRTC
                }

                override fun onCatalog(ownerId: String, ownerName: String, files: List<SharedFile>) {
                    repo.applyCatalogFromOwner(group.id, ownerId, ownerName, files)
                }
            })
            rendezvous.announceCatalog(repo.myFilesIn(group.id))
        }
    }

    /** À appeler après que j'ai ajouté des fichiers : ré-annonce mon catalogue. */
    fun reannounceMyFiles() {
        rendezvous?.announceCatalog(repo.myFilesIn(group.id))
        // Le serveur local lit mes fichiers en direct : rien à faire côté LAN.
    }

    /**
     * Télécharge un fichier en choisissant le transport :
     *  - propriétaire découvert en local → téléchargement HTTP direct (RÉEL) ;
     *  - sinon (distant) → transfert WebRTC via le serveur de rendez-vous.
     */
    fun download(file: SharedFile) {
        val lanPeer = lan.peers.value.firstOrNull { it.memberId == file.ownerId }
        if (lanPeer != null) {
            TransferService.start(context)
            val job = scope.launch {
                lan.downloadFile(lanPeer, file) { progress -> repo.setDownload(progress) }
            }
            cancellers[file.id] = { job.cancel() }
        } else if (serverConfigured()) {
            TransferService.start(context)
            cancellers[file.id] = { webRtc.close(file.ownerId) }
            webRtc.requestDownload(file.ownerId, file)
        } else {
            repo.markDownload(file, TransferState.TRANSFERRING)
            val job = scope.launch {
                delay(700)
                repo.markDownload(file, TransferState.DONE, file.sizeBytes)
            }
            cancellers[file.id] = { job.cancel() }
        }
    }

    /** Annule un téléchargement en cours et le retire du suivi. */
    fun cancel(fileId: String) {
        cancellers.remove(fileId)?.invoke()
        repo.clearDownload(fileId)
    }

    private fun serverConfigured(): Boolean =
        AppConfig.RENDEZVOUS_URL?.let { it.startsWith("wss://") && !it.contains("VOTRE-SERVEUR") } == true

    fun stop() {
        rendezvous?.close()
        lan.stop()
        runCatching { webRtc.close() }
        scope.cancel()
    }
}
