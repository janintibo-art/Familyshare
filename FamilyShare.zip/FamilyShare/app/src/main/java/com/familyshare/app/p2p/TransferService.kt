package com.familyshare.app.p2p

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.familyshare.app.data.model.TransferState
import com.familyshare.app.data.repository.GroupRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * Service de premier plan qui maintient les transferts actifs même quand l'app
 * passe en arrière-plan ou que l'écran est éteint. Il observe [GroupRepository],
 * met à jour une notification de progression, et s'arrête tout seul quand plus
 * aucun transfert n'est en cours.
 */
class TransferService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var sawActive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startInForeground(buildNotification("Préparation du transfert…", indeterminate = true))
        watchTransfers()
        // Filet de sécurité : si aucun transfert ne démarre vraiment, on s'arrête.
        scope.launch {
            delay(10_000)
            if (!sawActive) stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun watchTransfers() {
        watcher = scope.launch {
            GroupRepository.get().downloads.collect { map ->
                val active = map.values.filter {
                    it.state == TransferState.TRANSFERRING || it.state == TransferState.PENDING
                }
                if (active.isEmpty()) {
                    if (sawActive) stopSelf()
                    return@collect
                }
                sawActive = true
                val total = active.sumOf { it.totalBytes }.coerceAtLeast(1)
                val done = active.sumOf { it.bytesTransferred }
                val pct = (done * 100 / total).toInt()
                val title = if (active.size == 1) {
                    "Téléchargement : ${active.first().fileName}"
                } else {
                    "Téléchargement de ${active.size} fichiers"
                }
                notify(buildNotification(title, progress = pct))
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Transferts",
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Progression des transferts de fichiers" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, progress: Int = 0, indeterminate: Boolean = false): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FamilyShare")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()

    private fun notify(n: Notification) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    private fun startInForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        watcher?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "transfers"
        private const val NOTIF_ID = 1001

        /** Démarre le service (à appeler quand un transfert réel commence). */
        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java))
        }
    }
}
