package com.familyshare.app.ui.screens.group

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.di.AppModule
import com.familyshare.app.p2p.GroupSession
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Détient la [GroupSession] du groupe ouvert. La session démarre à l'entrée dans
 * l'écran et s'arrête quand le ViewModel est détruit (sortie de l'écran), ce qui
 * évite de laisser tourner la découverte/le serveur local en arrière-plan.
 */
class GroupCatalogViewModel : ViewModel() {

    private var session: GroupSession? = null
    private var startedGroupId: String? = null

    /** Vrai pendant la fenêtre initiale de découverte mDNS (pour l'état « Recherche… »). */
    private val _searching = MutableStateFlow(false)
    val searching: StateFlow<Boolean> = _searching.asStateFlow()

    fun start(appContext: Context, groupId: String) {
        if (startedGroupId == groupId && session != null) return
        session?.stop()
        val group = AppModule.repository.groupById(groupId) ?: return
        session = GroupSession(appContext, group).also { it.start() }
        startedGroupId = groupId
        _searching.value = true
        viewModelScope.launch {
            delay(5_000)
            _searching.value = false
        }
    }

    /** Mes fichiers viennent de changer : ré-annonce le catalogue au groupe. */
    fun onFilesContributed() {
        session?.reannounceMyFiles()
    }

    fun download(files: List<SharedFile>) {
        files.forEach { session?.download(it) }
    }

    fun cancel(fileId: String) {
        session?.cancel(fileId)
    }

    override fun onCleared() {
        session?.stop()
        session = null
    }
}
