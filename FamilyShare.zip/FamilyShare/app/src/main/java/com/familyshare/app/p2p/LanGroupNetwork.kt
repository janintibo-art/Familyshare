package com.familyshare.app.p2p

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.familyshare.app.data.model.Group
import com.familyshare.app.data.model.GroupMember
import com.familyshare.app.data.model.SharedFile
import com.familyshare.app.data.model.TransferProgress
import com.familyshare.app.data.model.TransferState
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.SequenceInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.CipherInputStream
import kotlin.coroutines.coroutineContext

/**
 * Réseau de groupe SANS SERVEUR, façon eMule sur réseau local — IMPLÉMENTATION RÉELLE.
 *
 *  - DÉCOUVERTE : NSD/mDNS. On publie un service `_familyshare._tcp` étiqueté avec
 *    l'ID du groupe ; on découvre les autres membres du même groupe sur le Wi-Fi.
 *  - PARTAGE : un mini-serveur HTTP local (NanoHTTPD) sert MES fichiers
 *    (`GET /catalog`, `GET /file?id=`), protégé par le secret du groupe.
 *  - TÉLÉCHARGEMENT : on récupère le catalogue puis le fichier directement sur le
 *    téléphone hôte (HTTP), écrit dans le dossier de l'app, avec progression.
 *
 * Fonctionne quand les téléphones sont sur le même réseau local.
 */
class LanGroupNetwork(private val context: Context) {

    private val _peers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val peers: StateFlow<List<DiscoveredPeer>> = _peers

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running

    private val nsd: NsdManager? = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private var multicastLock: WifiManager.MulticastLock? = null

    private var server: FileHttpServer? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private var group: Group? = null
    private var myServiceName: String = ""

    // NSD ne résout qu'un service à la fois de façon fiable (surtout < Android 12) :
    // on sérialise les résolutions dans une file pour éviter les plantages.
    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    fun start(group: Group, me: GroupMember, sharedFilesProvider: () -> List<SharedFile>) {
        if (_running.value) stop()
        this.group = group
        acquireMulticastLock()

        // 1. Mini-serveur HTTP local (sert MES fichiers, lus en direct).
        val srv = FileHttpServer(context, group.secret, sharedFilesProvider)
        runCatching { srv.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
        server = srv

        // 2. Publication NSD + 3. découverte des membres du même groupe.
        registerService(group, me, srv.listeningPort)
        startDiscovery(group)

        _running.value = true
    }

    fun stop() {
        runCatching { discoveryListener?.let { nsd?.stopServiceDiscovery(it) } }
        runCatching { registrationListener?.let { nsd?.unregisterService(it) } }
        discoveryListener = null
        registrationListener = null
        runCatching { server?.stop() }
        server = null
        synchronized(resolveQueue) { resolveQueue.clear(); resolving = false }
        _peers.value = emptyList()
        releaseMulticastLock()
        _running.value = false
    }

    // ---------------------------------------------------------------- client HTTP

    /** Récupère le catalogue d'un pair : GET http://host:port/catalog. */
    suspend fun fetchCatalog(peer: DiscoveredPeer): List<SharedFile> = withContext(Dispatchers.IO) {
        val secret = group?.secret.orEmpty()
        val conn = open("http://${peer.host}:${peer.port}/catalog?secret=${enc(secret)}", readTimeout = 5000)
        try {
            if (conn.responseCode != 200) return@withContext emptyList()
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        SharedFile(
                            id = o.optString("id"),
                            name = o.optString("name"),
                            sizeBytes = o.optLong("sizeBytes"),
                            mimeType = o.optString("mimeType", "application/octet-stream"),
                            uri = "",
                            ownerId = peer.memberId,
                            ownerName = peer.name,
                        )
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Télécharge un fichier depuis le téléphone hôte et l'enregistre dans la
     * galerie (Photos / Vidéos / Musique, dossier « FamilyShare ») sur Android 10+,
     * ou dans le dossier de l'app sur les versions antérieures, avec progression.
     */
    suspend fun downloadFile(
        peer: DiscoveredPeer,
        file: SharedFile,
        onProgress: (TransferProgress) -> Unit,
    ): Boolean = withContext(Dispatchers.IO) {
        val secret = group?.secret.orEmpty()
        val conn = open("http://${peer.host}:${peer.port}/file?id=${enc(file.id)}&secret=${enc(secret)}", readTimeout = 20000)
        try {
            if (conn.responseCode != 200) {
                onProgress(TransferProgress(file.id, file.name, 0, file.sizeBytes, TransferState.FAILED))
                return@withContext false
            }
            val total = if (conn.contentLength > 0) conn.contentLength.toLong() else file.sizeBytes
            onProgress(TransferProgress(file.id, file.name, 0, total, TransferState.TRANSFERRING))

            val sink = openSink(file.name, file.mimeType)
            if (sink == null) {
                onProgress(TransferProgress(file.id, file.name, 0, total, TransferState.FAILED))
                return@withContext false
            }
            var done = 0L
            conn.inputStream.use { rawIn ->
                // Lit l'IV en tête, puis déchiffre le reste en flux (AES-CTR).
                val iv = ByteArray(TransferCrypto.IV_LEN)
                readFully(rawIn, iv)
                val input = CipherInputStream(rawIn, TransferCrypto.decryptCipher(secret, iv))
                sink.stream.use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    while (input.read(buf).also { read = it } != -1) {
                        coroutineContext.ensureActive() // coupe proprement à l'annulation
                        out.write(buf, 0, read)
                        done += read
                        onProgress(TransferProgress(file.id, file.name, done, total, TransferState.TRANSFERRING))
                    }
                }
            }
            finalizeSink(sink)
            onProgress(TransferProgress(file.id, file.name, done, total, TransferState.DONE, sink.uri?.toString()))
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onProgress(TransferProgress(file.id, file.name, 0, file.sizeBytes, TransferState.FAILED))
            false
        } finally {
            conn.disconnect()
        }
    }

    private class Sink(val stream: OutputStream, val uri: Uri?)

    /** Ouvre la destination : galerie (MediaStore) sur Android 10+, sinon dossier de l'app. */
    private fun openSink(name: String, mime: String): Sink? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
            val (collection, relPath) = when {
                mime.startsWith("image/") -> MediaStore.Images.Media.getContentUri(vol) to "${Environment.DIRECTORY_PICTURES}/FamilyShare"
                mime.startsWith("video/") -> MediaStore.Video.Media.getContentUri(vol) to "${Environment.DIRECTORY_MOVIES}/FamilyShare"
                mime.startsWith("audio/") -> MediaStore.Audio.Media.getContentUri(vol) to "${Environment.DIRECTORY_MUSIC}/FamilyShare"
                else -> MediaStore.Downloads.getContentUri(vol) to "${Environment.DIRECTORY_DOWNLOADS}/FamilyShare"
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: return null
            val out = resolver.openOutputStream(uri) ?: return null
            Sink(out, uri)
        } else {
            val dir = File(context.getExternalFilesDir(null), "FamilyShare").apply { mkdirs() }
            val f = File(dir, name)
            Sink(FileOutputStream(f), Uri.fromFile(f))
        }
    } catch (e: Exception) {
        null
    }

    private fun finalizeSink(sink: Sink) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && sink.uri != null) {
            runCatching {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(sink.uri, values, null, null)
            }
        }
    }

    private fun open(url: String, readTimeout: Int): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 4000
            this.readTimeout = readTimeout
        }

    // ---------------------------------------------------------------- NSD

    private fun registerService(group: Group, me: GroupMember, port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "FamilyShare-${me.id.take(6)}-${(0..9999).random()}"
            serviceType = SERVICE_TYPE
            setPort(port)
            setAttribute("group", group.id)
            setAttribute("member", me.id)
            setAttribute("name", me.displayName)
        }
        myServiceName = info.serviceName
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) { myServiceName = info.serviceName }
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        registrationListener = listener
        runCatching { nsd?.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    private fun startDiscovery(group: Group) {
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                if (info.serviceName == myServiceName) return
                enqueueResolve(info)
            }
            override fun onServiceLost(info: NsdServiceInfo) {
                _peers.value = _peers.value.filterNot { it.serviceName == info.serviceName }
            }
        }
        discoveryListener = listener
        runCatching { nsd?.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    private fun enqueueResolve(info: NsdServiceInfo) {
        synchronized(resolveQueue) { resolveQueue.addLast(info) }
        resolveNext()
    }

    private fun resolveNext() {
        val next: NsdServiceInfo
        synchronized(resolveQueue) {
            if (resolving || resolveQueue.isEmpty()) return
            resolving = true
            next = resolveQueue.removeFirst()
        }
        val grp = group
        nsd?.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                synchronized(resolveQueue) { resolving = false }
                resolveNext()
            }
            override fun onServiceResolved(resolved: NsdServiceInfo) {
                val attrs = resolved.attributes ?: emptyMap()
                fun attr(k: String): String? = attrs[k]?.let { String(it) }
                val host = resolved.host?.hostAddress
                if (grp != null && attr("group") == grp.id && host != null) {
                    val peer = DiscoveredPeer(
                        memberId = attr("member") ?: resolved.serviceName,
                        name = attr("name") ?: "Membre",
                        host = host,
                        port = resolved.port,
                        serviceName = resolved.serviceName,
                    )
                    _peers.value = _peers.value.filterNot { it.serviceName == peer.serviceName } + peer
                }
                synchronized(resolveQueue) { resolving = false }
                resolveNext()
            }
        })
    }

    // ---------------------------------------------------------------- multicast

    private fun acquireMulticastLock() {
        runCatching {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("familyshare")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching { if (multicastLock?.isHeld == true) multicastLock?.release() }
        multicastLock = null
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    // ---------------------------------------------------------------- serveur local

    /** Mini-serveur HTTP : sert UNIQUEMENT mes fichiers, derrière le secret du groupe. */
    private class FileHttpServer(
        private val context: Context,
        private val secret: String,
        private val filesProvider: () -> List<SharedFile>,
    ) : NanoHTTPD(LanGroupNetwork.DEFAULT_PORT) {

        override fun serve(session: IHTTPSession): Response {
            val params = session.parameters
            val given = params["secret"]?.firstOrNull().orEmpty()
            if (secret.isNotEmpty() && given != secret) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "secret invalide")
            }
            return when (session.uri) {
                "/catalog" -> catalog()
                "/file" -> file(params["id"]?.firstOrNull())
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "introuvable")
            }
        }

        private fun catalog(): Response {
            val arr = JSONArray()
            filesProvider().forEach { f ->
                arr.put(
                    JSONObject()
                        .put("id", f.id).put("name", f.name)
                        .put("sizeBytes", f.sizeBytes).put("mimeType", f.mimeType)
                )
            }
            return newFixedLengthResponse(Response.Status.OK, "application/json", arr.toString())
        }

        private fun file(id: String?): Response {
            val f = filesProvider().firstOrNull { it.id == id }
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "fichier inconnu")
            return try {
                val input = context.contentResolver.openInputStream(Uri.parse(f.uri))
                    ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "lecture impossible")
                // Chiffre le flux (AES-CTR) avec une clé dérivée du secret du groupe ; l'IV est en tête.
                val (iv, cipher) = TransferCrypto.newEncryptCipher(secret)
                val body = SequenceInputStream(ByteArrayInputStream(iv), CipherInputStream(input, cipher))
                newChunkedResponse(Response.Status.OK, "application/octet-stream", body)
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "erreur")
            }
        }
    }

    data class DiscoveredPeer(
        val memberId: String,
        val name: String,
        val host: String,
        val port: Int,
        val serviceName: String = "",
    )

    companion object {
        const val SERVICE_TYPE = "_familyshare._tcp."
        const val DEFAULT_PORT = 8765
    }
}

/** Lit exactement buf.size octets depuis le flux (pour l'IV en tête), sinon lève une erreur. */
private fun readFully(input: InputStream, buf: ByteArray) {
    var off = 0
    while (off < buf.size) {
        val n = input.read(buf, off, buf.size - off)
        if (n < 0) throw java.io.IOException("flux trop court pour l'IV")
        off += n
    }
}
