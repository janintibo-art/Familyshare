plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.familyshare.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.familyshare.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    // Jetpack Compose (Material 3)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    // Coroutines + sérialisation
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    // Stockage léger des préférences (DataStore) et accès SAF aux dossiers
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.documentfile)

    // Chargement d'images / vignettes
    implementation(libs.coil.compose)

    // QR codes (invitations de groupe) + scanner caméra
    implementation(libs.zxing.core)
    implementation(libs.zxing.embedded)
    // Mini-serveur HTTP local (chaque appareil sert ses fichiers au groupe, façon eMule)
    implementation(libs.nanohttpd)
    // WebSocket vers le serveur de rendez-vous (signaling pour les membres distants)
    implementation(libs.okhttp)
    // WebRTC : pont 1-à-1 optionnel pour un membre distant (sans serveur)
    implementation(libs.webrtc.android)

    debugImplementation(libs.androidx.ui.tooling)
}
