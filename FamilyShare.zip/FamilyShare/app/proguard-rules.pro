# Règles ProGuard / R8

# Garde les classes de modèle sérialisées par kotlinx.serialization
-keepclassmembers class **$$serializer { *; }
-keep,includedescriptorclasses class com.familyshare.app.data.model.** { *; }
-keepclasseswithmembers class com.familyshare.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# WebRTC (JNI)
-keep class org.webrtc.** { *; }
-keep class io.getstream.webrtc.** { *; }
-dontwarn org.webrtc.**
